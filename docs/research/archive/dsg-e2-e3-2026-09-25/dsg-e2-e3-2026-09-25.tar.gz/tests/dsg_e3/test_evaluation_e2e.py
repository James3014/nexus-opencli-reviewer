"""
End-to-End Pytest Suite for DSG-E3 Runtime Verifier Evaluation
"""
from __future__ import annotations

import pytest

from reviewer.deterministic_guard.dsg_e3_runtime_verifier.runner import run_full_evaluation


def test_full_dsg_e3_evaluation_pipeline():
    eval_res = run_full_evaluation()

    # 1. Verify Development Anchors achieve VIOLATION_BEFORE_ONLY
    dev_results = eval_res["development_results"]
    assert len(dev_results) == 3
    for d in dev_results:
        assert d["outcome"] == "VIOLATION_BEFORE_ONLY"

    # 2. Verify Unseen Holdouts achieve VIOLATION_BEFORE_ONLY
    holdout_results = eval_res["unseen_holdout_results"]
    assert len(holdout_results) == 4
    for h in holdout_results:
        assert h["outcome"] == "VIOLATION_BEFORE_ONLY"

    # 3. Verify Benign Controls achieve PASS_THROUGH (0% False Positives)
    benign_results = eval_res["benign_control_results"]
    assert len(benign_results) >= 4
    for b in benign_results:
        assert b["status"] == "PASS_THROUGH"
        assert b["verdict"] == "PASS"

    # 4. Verify Metamorphic Invariance Tests
    meta_results = eval_res["metamorphic_results"]
    assert len(meta_results) == 2
    for m in meta_results:
        assert m["pass"] is True
