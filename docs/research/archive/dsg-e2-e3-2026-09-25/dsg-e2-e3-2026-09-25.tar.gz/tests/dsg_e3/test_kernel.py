"""
Focused Unit Tests for DSG-E3 Runtime Verifier Kernel & Adapters
"""
from __future__ import annotations

import tempfile
from pathlib import Path

import pytest

from reviewer.deterministic_guard.dsg_e3_runtime_verifier.adapter_interface import BaseSubjectAdapter
from reviewer.deterministic_guard.dsg_e3_runtime_verifier.dev_adapters import (
    DevCase1StoreAdapter,
    DevCase2WikiGateAdapter,
    DevCase5CutoverAdapter,
)
from reviewer.deterministic_guard.dsg_e3_runtime_verifier.kernel import (
    EventType,
    GenericRuntimeVerifierKernel,
    InvariantVerdict,
    RuntimeEvent,
)


def test_kernel_rv1_path_containment_direct():
    kernel = GenericRuntimeVerifierKernel()
    with tempfile.TemporaryDirectory() as td:
        root = Path(td) / "state"
        root.mkdir()
        safe_target = root / "valid.json"
        safe_target.touch()

        # Safe event
        res_safe = kernel.evaluate_trace([
            RuntimeEvent(event_type=EventType.FS_EFFECT, target_path=str(safe_target), trusted_root=str(root))
        ])
        assert res_safe.verdict == InvariantVerdict.PASS

        # Escaping event via ..
        escape_target = root / "../escaped.json"
        res_escape = kernel.evaluate_trace([
            RuntimeEvent(event_type=EventType.FS_EFFECT, target_path=str(escape_target), trusted_root=str(root))
        ])
        assert res_escape.verdict == InvariantVerdict.VIOLATION
        assert any("RV1_VIOLATION" in v for v in res_escape.violations)


def test_kernel_rv2_isolated_execution_direct():
    kernel = GenericRuntimeVerifierKernel()
    with tempfile.TemporaryDirectory() as td:
        auth_root = Path(td) / "repo"
        auth_root.mkdir()
        temp_dir = Path(td) / "temp_sandbox"
        temp_dir.mkdir()

        # Mutating in authoritative root -> Violation
        res_bad = kernel.evaluate_trace([
            RuntimeEvent(
                event_type=EventType.PROC_EXEC,
                exec_cwd=str(auth_root),
                authoritative_root=str(auth_root),
                is_mutating=True,
                is_ephemeral=False,
            )
        ])
        assert res_bad.verdict == InvariantVerdict.VIOLATION

        # Mutating in temp sandbox -> Pass
        res_good = kernel.evaluate_trace([
            RuntimeEvent(
                event_type=EventType.PROC_EXEC,
                exec_cwd=str(temp_dir),
                authoritative_root=str(auth_root),
                is_mutating=True,
                is_ephemeral=True,
            )
        ])
        assert res_good.verdict == InvariantVerdict.PASS


def test_kernel_rv3_validation_precedes_effect_direct():
    kernel = GenericRuntimeVerifierKernel()

    # Case A: Validation PASS before effect -> PASS
    trace_valid = [
        RuntimeEvent(event_type=EventType.VALIDATION_PASS, operation_id="op-1"),
        RuntimeEvent(event_type=EventType.PROTECTED_EFFECT, operation_id="op-1"),
    ]
    assert kernel.evaluate_trace(trace_valid).verdict == InvariantVerdict.PASS

    # Case B: Effect before validation -> VIOLATION
    trace_invalid_order = [
        RuntimeEvent(event_type=EventType.PROTECTED_EFFECT, operation_id="op-1"),
        RuntimeEvent(event_type=EventType.VALIDATION_PASS, operation_id="op-1"),
    ]
    res_b = kernel.evaluate_trace(trace_invalid_order)
    assert res_b.verdict == InvariantVerdict.VIOLATION
    assert any("without preceding validation" in v for v in res_b.violations)

    # Case C: Validation FAIL then effect -> VIOLATION
    trace_fail_effect = [
        RuntimeEvent(event_type=EventType.VALIDATION_FAIL, operation_id="op-1"),
        RuntimeEvent(event_type=EventType.PROTECTED_EFFECT, operation_id="op-1"),
    ]
    res_c = kernel.evaluate_trace(trace_fail_effect)
    assert res_c.verdict == InvariantVerdict.VIOLATION
    assert any("after validation failure" in v for v in res_c.violations)
