"""
E2E Pytest Suite for DSG-E3 Physical Subject Replay Completion

Verifies:
1. Frozen artifact hashes (kernel, adapter_interface, protocols, budget).
2. Adapter budget compliance (<= 60 LOC, no case branching, no expected verdicts).
3. 6/6 Physical HIGH historical subjects achieve VIOLATION_BEFORE_ONLY.
4. 6/6 Physical Benign controls achieve PASS_THROUGH (0% FP).
5. Metamorphic and falsification suites pass.
"""
from __future__ import annotations

import hashlib
import inspect
from pathlib import Path
import pytest

from reviewer.deterministic_guard.dsg_e3_runtime_verifier.physical_replay import physical_adapters
from reviewer.deterministic_guard.dsg_e3_runtime_verifier.physical_replay.replay_runner import run_physical_replay


FROZEN_HASHES = {
    "reviewer/deterministic_guard/dsg_e3_runtime_verifier/kernel.py":
        "cc80eab967961131d7715783e625d4ddff470564c6049a96f82495ecb6d7cf30",
    "reviewer/deterministic_guard/dsg_e3_runtime_verifier/adapter_interface.py":
        "3d2ceeeecfd5fcd9c7381059d5a3758bb615d863dff02f0cfb5536b879a8333a",
    "docs/research/dsg_e3/DSG_E3_RUNTIME_INVARIANT_PROTOCOL_V1.md":
        "be85848ece22dd18380b611367ded2ef7ac352e4b9c428db7546f76cec132c47",
    "docs/research/dsg_e3/DSG_E3_RUNTIME_HOLDOUT_SELECTION_PROTOCOL_V1.md":
        "db02798cfcb6b5b51af11ae1323436a3f01f2078ef1310f73666ed94379b82a4",
    "docs/research/dsg_e3/DSG_E3_ADAPTER_BUDGET_V1.md":
        "4271af683fa59ecdbd73831e0ee5508a63cba8e787419c58bb031ab1484fc610",
}


def test_frozen_artifacts_integrity():
    for rel_path, expected_sha in FROZEN_HASHES.items():
        file_bytes = Path(rel_path).read_bytes()
        actual_sha = hashlib.sha256(file_bytes).hexdigest()
        assert actual_sha == expected_sha, f"Frozen artifact {rel_path} integrity failure! Expected {expected_sha}, got {actual_sha}"


def test_physical_adapter_budget_and_shape():
    adapter_classes = [
        physical_adapters.PhysicalTaskServiceAdapter,
        physical_adapters.PhysicalProjectionAdapter,
        physical_adapters.PhysicalSandboxAdapter,
        physical_adapters.PhysicalExecutorCleanupAdapter,
        physical_adapters.PhysicalShutdownFencingAdapter,
        physical_adapters.PhysicalGatewayFencingAdapter,
    ]
    assert len(adapter_classes) == 6

    for cls in adapter_classes:
        source_lines = inspect.getsourcelines(cls)[0]
        # Filter comments and blank lines for logical LOC
        logical_loc = [l for l in source_lines if l.strip() and not l.strip().startswith("#")]
        assert len(logical_loc) <= 60, f"{cls.__name__} exceeds 60 logical LOC ({len(logical_loc)})"

        source_code = "".join(source_lines)
        assert "InvariantVerdict" not in source_code, f"{cls.__name__} references InvariantVerdict"
        assert "verdict =" not in source_code, f"{cls.__name__} hardcodes verdict"
        assert "case_id" not in source_code, f"{cls.__name__} branches on case_id"
        assert "is_before" not in source_code, f"{cls.__name__} branches on is_before"


def test_physical_replay_execution_all_cases():
    results = run_physical_replay()
    assert results["execution_mode"] == "PHYSICAL_HISTORICAL_SUBJECT_REPLAY"

    high_cases = results["high_cases"]
    assert len(high_cases) == 6
    for h in high_cases:
        assert h["outcome"] == "VIOLATION_BEFORE_ONLY", f"HIGH case {h['case_id']} failed outcome check: {h}"
        assert h["verdict_before"] == "VIOLATION"
        assert h["verdict_after"] == "PASS"
        assert h["target_branch_executed"] is True

    benign_cases = results["benign_controls"]
    assert len(benign_cases) == 6
    for b in benign_cases:
        assert b["status"] == "PASS_THROUGH"
        assert b["verdict"] == "PASS"

    meta_results = results["metamorphic_results"]
    assert len(meta_results) == 5
    for m in meta_results:
        assert m["passed"] is True, f"Metamorphic test failed: {m}"
