from __future__ import annotations

import copy
import subprocess
from pathlib import Path

import pytest

from reviewer.deterministic_guard.source_bound_corpus import (
    extract_git_case,
    extract_git_single_commit,
    verify_source_bound_corpus,
)


def _git(repo: Path, *args: str) -> str:
    return subprocess.run(
        ["git", "-C", str(repo), *args],
        check=True,
        capture_output=True,
        text=True,
    ).stdout.strip()


@pytest.fixture()
def history_repo(tmp_path: Path) -> tuple[Path, str, str]:
    repo = tmp_path / "history"
    repo.mkdir()
    _git(repo, "init", "-q")
    _git(repo, "config", "user.name", "Verifier Test")
    _git(repo, "config", "user.email", "verifier@example.invalid")

    (repo / "target.py").write_text("value = 'before'\n", encoding="utf-8")
    (repo / "other.py").write_text("other = 'stable'\n", encoding="utf-8")
    _git(repo, "add", "target.py", "other.py")
    _git(repo, "commit", "-q", "-m", "initial")
    before = _git(repo, "rev-parse", "HEAD")

    (repo / "target.py").write_text("value = 'after'\n", encoding="utf-8")
    _git(repo, "add", "target.py")
    _git(repo, "commit", "-q", "-m", "fix target")
    after = _git(repo, "rev-parse", "HEAD")
    return repo, before, after


def _pair(repo: Path, after: str):
    return extract_git_case(
        repo_path=str(repo),
        repo_full_name="example/history",
        commit_after=after,
        file_path="target.py",
        risk_truth_before="HIGH_RISK",
        risk_truth_after="LOW_RISK",
        scenario_family="TEST_HISTORY",
        provenance_note="test provenance",
        case_prefix="case",
        stratum="REAL_EXTERNAL_SECURITY_HISTORY",
    )


def _verify(cases, repo: Path):
    return verify_source_bound_corpus(cases, {"example/history": str(repo)})


def test_verifier_accepts_exact_commit_path_blob_content_and_diff(history_repo):
    repo, _before, after = history_repo
    cases = _pair(repo, after)

    result = _verify(cases, repo)

    assert result["status"] == "PASS"
    assert result["verified_count"] == 2
    assert result["ineligible_count"] == 0
    assert result["pair_verified_count"] == 1
    assert result["pair_invalid_count"] == 0
    assert result["checks"] == {
        "commit_identity": 2,
        "parent_relation": 2,
        "path_blob_binding": 2,
        "content_bytes": 2,
        "patch_hash": 2,
        "diff_bytes": 2,
    }


@pytest.mark.parametrize(
    "tamper",
    [
        "path",
        "blob_before",
        "blob_after",
        "patch_hash",
        "content",
        "diff",
        "commit_before",
        "commit_after",
        "swapped_content",
        "content_side",
    ],
)
def test_verifier_rejects_provenance_tampering(history_repo, tamper):
    repo, before, after = history_repo
    cases = _pair(repo, after)
    candidate = copy.deepcopy(cases[0])

    if tamper == "path":
        candidate.path = "other.py"
    elif tamper == "blob_before":
        candidate.blob_sha_before = _git(repo, "rev-parse", f"{before}:other.py")
    elif tamper == "blob_after":
        candidate.blob_sha_after = _git(repo, "rev-parse", f"{after}:other.py")
    elif tamper == "patch_hash":
        candidate.patch_sha256 = "0" * 64
    elif tamper == "content":
        candidate.content += "# tampered\n"
    elif tamper == "diff":
        candidate.diff += "\n# tampered"
    elif tamper == "commit_before":
        candidate.commit_before = after
    elif tamper == "commit_after":
        candidate.commit_after = before
    elif tamper == "swapped_content":
        candidate.content = cases[1].content
    elif tamper == "content_side":
        candidate.content_side = "AFTER"
    else:
        raise AssertionError(tamper)

    result = _verify([candidate], repo)

    assert result["status"] == "FAIL"
    assert result["verified_count"] == 0
    assert result["ineligible_count"] == 1
    assert candidate.case_id in result["ineligible_case_ids"]


def test_existing_but_wrong_blob_is_not_path_bound_provenance(history_repo):
    repo, before, after = history_repo
    cases = _pair(repo, after)
    candidate = copy.deepcopy(cases[0])
    wrong_existing_blob = _git(repo, "rev-parse", f"{before}:other.py")
    assert _git(repo, "cat-file", "-t", wrong_existing_blob) == "blob"

    candidate.blob_sha_before = wrong_existing_blob
    result = _verify([candidate], repo)

    assert result["status"] == "FAIL"
    assert any("commit_before:path blob mismatch" in reason for reason in result["reasons"])


def test_single_commit_extraction_binds_parent_and_after_blobs(history_repo):
    repo, _before, after = history_repo
    (repo / "target.py").write_text("value = 'third'\n", encoding="utf-8")
    _git(repo, "add", "target.py")
    _git(repo, "commit", "-q", "-m", "third")
    third = _git(repo, "rev-parse", "HEAD")

    case = extract_git_single_commit(
        repo_path=str(repo),
        repo_full_name="example/history",
        commit=third,
        file_path="target.py",
        risk_truth="LOW_RISK",
        scenario_family="BENIGN_TEST",
        provenance_note="benign history",
        case_id="single",
        stratum="REAL_EXTERNAL_SECURITY_HISTORY",
    )

    assert case.commit_before == after
    assert case.blob_sha_before == _git(repo, "rev-parse", f"{after}:target.py")
    assert case.blob_sha_after == _git(repo, "rev-parse", f"{third}:target.py")
    assert case.blob_sha_before != case.blob_sha_after
    assert case.content_side == "AFTER"
    assert _verify([case], repo)["status"] == "PASS"
