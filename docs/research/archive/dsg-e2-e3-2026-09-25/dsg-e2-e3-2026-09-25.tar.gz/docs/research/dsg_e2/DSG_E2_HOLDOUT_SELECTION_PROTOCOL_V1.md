# DSG_E2_HOLDOUT_SELECTION_PROTOCOL_V1

## 1. Purpose & Anti-Overfitting Pre-Commitment
This protocol pre-commits the selection criteria, source-bound provenance standards, and inclusion/exclusion rules for unseen evaluation cases BEFORE evaluating custom reusable queries.
Frozen truth labels and physical git object provenance must be verifiable prior to scoring.

## 2. Invariant Families Under Evaluation
- **RQ1**: Path containment before filesystem read/write/traversal effect
- **RQ2**: Subprocess execution isolation / workspace boundary enforcement
- **RQ3**: Validation before privileged / irreversible effect ordering

## 3. Eligible Repository Universe
1. Authentic Nexus repositories with full local history:
   - `James3014/Nexus-new`
   - `James3014/nexus-runtime`
   - `James3014/nexus-core`
   - `James3014/devspace`
2. Cloned external OSS repositories with confirmed security history:
   - `pallets/werkzeug`
   - `yaml/pyyaml`

## 4. Date Window & Provenance Criteria
- Any commit strictly prior to 2026-09-25T00:00:00Z.
- Must satisfy full Source-Bound Case Contract (Commit-Before, Commit-After, Commit-After^1 == Commit-Before, Commit-Before:Path -> Blob, Commit-After:Path -> Blob, Exact Content Bytes, Fresh Git Diff, Patch SHA-256).

## 5. Candidate Selection: Unseen HIGH Fixes (Target: >= 6 cases across RQ1, RQ2, RQ3)
- **RQ1 Unseen 1**: `James3014/Nexus-new` @ `43ffd1b67d97e7782dc24a6a2062e21b5f9239e8` (`nexus/research/epistemic_benchmark/observations.py`)
  - Family: PATH_CONTAINMENT_SYMLINK_ESCAPE
  - Pre-fix: lack of symlink / root containment checks on imported observation paths.
  - Post-fix: enforces `_validate_symlink_components` and `resolved_observation_root.startswith(resolved_run_root)`.
- **RQ1 Unseen 2**: `James3014/Nexus-new` @ `7dd3d9a83` (`nexus/orchestrator/worker_evidence.py` or similar worker path containment)
  - Family: PATH_CONTAINMENT_CONTROL_CHARS
  - Pre-fix: unvalidated path with control chars written to store.
  - Post-fix: path rejection before filesystem write.
- **RQ2 Unseen 1**: `James3014/Nexus-new` @ `cfbcdad14266aef86909832031ad35e14ee0cc0c` (`scripts/ops/wiki_ci_release_gate.py`)
  - Family: SUBPROCESS_WORKSPACE_ISOLATION
  - Pre-fix: execution root ran directly in repo root without temp execution root redirection.
  - Post-fix: creates `NEXUS_AUDIT_EXECUTION_ROOT` temp directory and isolates subprocess invocation.
- **RQ2 Unseen 2**: `James3014/Nexus-new` @ `9585eb95f` (`scripts/ops/wiki_ci_release_gate.py`)
  - Family: NESTED_ENV_ISOLATION
  - Pre-fix: subprocess executed with unisolated caller python environment.
  - Post-fix: parameterizes and isolates execution environment.
- **RQ3 Unseen 1**: `James3014/devspace` @ `8198c8dda56de09a9595477415b09b302c3f1a6b` (`src/workspaces.ts`)
  - Family: VALIDATION_BEFORE_EFFECT_ORDERING
  - Pre-fix: `deleteDurableSession` deleted session store before checking if workspace was loaded.
  - Post-fix: asserts `assertDurableSessionUnloaded` before calling `deleteSession`.
- **RQ3 Unseen 2**: `James3014/devspace` @ `96c38f990e8741649c568b9120eeb1e0e30b6657` (`src/server.ts`)
  - Family: VALIDATION_BEFORE_EFFECT_ORDERING
  - Pre-fix: delete operation did not pre-validate active workspace session references before removal.
  - Post-fix: rechecks references before delete effect.

## 6. Benign Controls (LOW_RISK) Selection (Target: >= 6 cases)
Must include legitimate commits modifying operational code without security vulnerability:
1. `James3014/nexus-runtime` @ `d65e3ea` (`test(runtime): remove redundant trailing blank lines`)
2. `James3014/nexus-runtime` @ `a1afe37` (`fix(context): preserve caller hotspot and knowledge fields`)
3. `James3014/nexus-core` @ `a26d1c6` (`feat(architecture): enforce authority boundaries from source dependency graph`)
4. `James3014/Nexus-new` @ `312784f` (`task(#973): add external Candidate adoption bridge R4`)
5. `James3014/devspace` @ `6b5e98a` (`feat: restore direct candidate execution evidence producer`)
6. `James3014/devspace` @ `46992b5` (`fix: bind host operations to workspace identity`)

## 7. Exclusion & No-Cherry-Pick Rules
- Known 8 development cases (`#1` through `#8`) are strictly EXCLUDED from holdout scoring.
- If an invariant cannot be statically formulated in Semgrep/CodeQL without overfitting, emit `INVARIANT_NOT_STATICALLY_EXPRESSIBLE_V1` rather than crafting a false pattern.
- No dropping of failed cases from denominator.
