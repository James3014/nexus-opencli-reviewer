# INVARIANT EXPRESSIBILITY TECHNICAL ASSESSMENT V1

## 1. Executive Summary
- **RQ1 (Path Containment Before Effect)**: Partially expressible, but syntactical heuristics without interprocedural taint fail to recognize custom validation methods (e.g., `self._validate_task_id(task_id)`), leading to non-discriminative `BOTH` noise unless domain symbols are leaked.
- **RQ2 (Subprocess Workspace Isolation)**: `INVARIANT_NOT_STATICALLY_EXPRESSIBLE_V1`.
- **RQ3 (Validation-Before-Effect Ordering)**: `INVARIANT_NOT_STATICALLY_EXPRESSIBLE_V1`.

## 2. Technical Breakdown

### RQ1: Path Containment
- Real-world path containment in production frameworks (such as Nexus `ExecutionStateStore` or Werkzeug `safe_join`) uses encapsulated helper methods (`_validate_task_id`, `_assert_contained`) or dynamic path resolution comparisons (`resolved.is_relative_to(root)`).
- Intraprocedural AST engines (Semgrep OSS) cannot trace whether an argument passed to a helper method on line 74 sanitized `task_id` before line 75's concatenation `path = self.state_dir / f"{task_id}.json"`.
- As a result, any generic rule flagging parameter concatenation flags BOTH pre-fix and post-fix code unless the rule hard-codes the exact name of the validation method (e.g. `_validate_task_id`), which violates anti-overfitting invariant #2.

### RQ2: Execution Isolation / Workspace Boundary
- In `scripts/ops/wiki_ci_release_gate.py` (Case #2 and Unseen Case `cfbcdad14`), the fix introduced a context manager `_audit_read_only_environment` that copies the repo to a `tempfile.TemporaryDirectory` and overrides environment variables `NEXUS_AUDIT_EXECUTION_ROOT`.
- The actual subprocess invocation (`subprocess.run(argv, cwd=execution_root, ...)`) has the exact same AST structure before and after! The difference is whether `execution_root` resolves to `repo_root` or `temp_dir`.
- Static pattern matchers cannot determine whether a variable passed to `cwd=` points to a sandboxed copy or an authoritative checkout without whole-program environment lifecycle awareness.
- **Formal Status**: `INVARIANT_NOT_STATICALLY_EXPRESSIBLE_V1`.

### RQ3: Validation-Before-Effect Ordering
- In `devspace` `src/workspaces.ts` (Unseen Case `8198c8d`), `deleteDurableSession` calls `this.assertDurableSessionUnloaded(workspaceId)` before `this.store?.deleteSession?.(workspaceId)`.
- In `devspace` `src/cli.ts` (Case #5), the fix added `confirmCutoverId !== cutoverId` check in an `if` condition before state mutation.
- A static rule cannot know which specific method invocation constitutes "privileged effect" vs "validation" across arbitrary business domains without hard-coding specific method names like `deleteSession` or `confirmCutoverId`.
- **Formal Status**: `INVARIANT_NOT_STATICALLY_EXPRESSIBLE_V1`.

## 3. Protocol Decision
In strict compliance with Anti-Overfitting Hard Rules #2, #6, and #16:
- We refuse to write benchmark-overfitted regex or hard-code domain method names.
- We declare RQ2 and RQ3 as `INVARIANT_NOT_STATICALLY_EXPRESSIBLE_V1`.
- For RQ1, we freeze the generic query manifest and record its physical discriminative behavior.
