# DSG_E2_REUSABLE_QUERY_PROTOCOL_V1

## 1. Protocol Definition & Scope
- **Protocol ID**: `DSG_E2_REUSABLE_QUERY_PROTOCOL_V1`
- **Claim Ceiling**: `REUSABLE_QUERY_PROBE_EVIDENCE_ONLY`
- **Candidate Context**: Commit `2a9e5e1ed357a7e8e45d047f0f200ed725e4026f`
- **Purpose**: Empirically evaluate whether small, reusable, non-case-specific semantic queries in Semgrep OSS provide incremental discriminative power over mature built-in analyzers on real historical security fixes without severe false positives.

## 2. Invariant Query Family Contracts

### RQ1: Path Containment Before Filesystem Effect
- **Abstract Invariant**: When an untrusted, externally-provided, or caller-parameterized identity participates in filesystem path resolution, it must undergo root containment validation or component sanitization before flowing into filesystem read/write/delete sinks.
- **Language**: Semgrep OSS (YAML)
- **Forbidden Tokens**: `ExecutionStateStore`, `task_id`, `state_dir`, `nexus_runtime`, commit SHAs, line numbers.
- **Generalization Target**: Generic path concatenation (`$ROOT / $PARAM` or `os.path.join($ROOT, $PARAM)`) lacking path containment barriers (`is_relative_to`, `resolve`, `abspath` check, or explicit validation).

### RQ2: Execution Isolation / Workspace Boundary
- **Abstract Invariant**: Subprocesses and command execution affecting repository or environment state must execute within an isolated temporary workspace or sandbox directory, rather than mutating the authoritative root in-place.
- **Language Assessment**:
  - Evaluation of whether generic AST patterns can distinguish "isolated subprocess" from "non-isolated subprocess" without knowing specific tool semantics.
  - If expressible without noisy regex: implement query.
  - If fundamentally dependent on runtime semantics / architectural conventions: declare `INVARIANT_NOT_STATICALLY_EXPRESSIBLE_V1`.

### RQ3: Validation-Before-Effect Ordering
- **Abstract Invariant**: Destructive, irreversible, or state-mutating actions must not proceed before verifying operation parameters, carrier/session consistency, or preconditions.
- **Language Assessment**:
  - Check whether control-flow ordering can be generalized across arbitrary APIs.
  - If impossible without exact domain symbols: declare `INVARIANT_NOT_STATICALLY_EXPRESSIBLE_V1`.

## 3. Scoring Matrix & Classification States
- **`BEFORE_ONLY`**: Detected in BEFORE version, NOT detected in AFTER version (True Catch / Incremental Protection).
- **`AFTER_ONLY`**: NOT detected in BEFORE, detected in AFTER (Inverse Noise / Regressive Alarm).
- **`BOTH`**: Detected in both BEFORE and AFTER (Non-discriminative Noise).
- **`NEITHER`**: Detected in neither BEFORE nor AFTER (Uncovered by Query).
- **`UNSUPPORTED`**: Language or file format not supported by the query engine.
- **`ERROR`**: Analysis engine failure or malformed input.
- **`INELIGIBLE`**: Provenance or binding could not be physically verified.

## 4. Denominator Discipline
- All selected holdout pairs remain in the denominator.
- No dropping of difficult cases.
- Inexpressible invariant families count as 0 discriminative catches.
