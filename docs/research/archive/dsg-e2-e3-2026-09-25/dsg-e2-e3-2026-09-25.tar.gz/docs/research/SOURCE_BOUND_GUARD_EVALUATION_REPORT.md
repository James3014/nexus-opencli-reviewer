# 確定性語意防護（Deterministic Semantic Guard）— 來源綁定驗證與權威歸屬報告
## Source-Bound Validation & Authority Contract Report

**最終判定**：`DETERMINISTIC_SEMANTIC_GUARD_RESEARCH_PROTOTYPE_ONLY`
**權威歸屬結論**：`SEMANTIC_GUARD_NEW_OWNER_RECOMMENDED`
**報告日期**：2026-09-25
**研究分支**：`research/deterministic-semantic-guard-candidate`
**研究倉庫**：`James3014/nexus-opencli-reviewer`（職責：研究/原型/評估，非生產 Safety Policy SSOT）

---

## 一、凍結源碼識別驗證（Guard D Frozen Identity）

Guard D 實作自 `aaf40bd` 凍結以來，在整個來源綁定歷史驗證過程中，**未修改任何一行規則或邏輯**：
- **Git Commit**：`aaf40bd859ec5041ed27c76f14169540e46c2a94`
- **Git Tree**：`f4427a947973828dad63e3a352015dcb25e5c63e`
- **Blob SHA (`reviewer/deterministic_guard/comparators.py`)**：`8a3e3c53d51570f1ea596e1ef97ab4619dab1b76`
- **SHA-256 實體位元組雜湊**：`696b0923e1da2c0726fee509f11dbeab94678e60d4412c36cec708538430e0fb`
- **一致性確認**：`VERIFIED_UNCHANGED`。

---

## 二、舊有 320 語料庫正式重新標定（Reclassification of Old Holdout）

先前的 `DSG_INDEPENDENT_HOLDOUT_V1`（320 筆）正式重新標定為：
$$\mathbf{DSG\_MIXED\_SYNTHETIC\_HOLDOUT\_V1 \quad (CONSTRUCTED\_HOLDOUT\_EVIDENCE\_ONLY)}$$
- **披露事實**：先前語料庫中的 Nexus 案例（`nexus-new:sim-{idx}`）與外部 OSS 案例（`oss-cve:patch-{idx}`）大量使用了人工依風險分類重寫的 Python 程式碼，並非綁定真實 Git 歷程的原始位元組。
- **保留價值**：保留其 74.4% High Catch 與 0.0% FP 之指標作為受控合成環境的參考基準，但**不得**作為 Candidate Acceptance 的實質依據。

---

## 三、來源綁定語料庫規範與機器驗證（DSGSourceBoundCaseV1 & Provenance Verifier）

本輪構建全新的來源綁定語料庫，嚴格依據 `DSGSourceBoundCaseV1` 合約，要求每一筆 `REAL_GIT_HISTORY` 必須具備：
`repository_full_name` + `commit_before` (parent) + `commit_after` + `path` + `blob_sha_before` + `blob_sha_after` + `patch_sha256`。

### 機器證明驗證結果（`verify_source_bound_corpus()`）：
- **驗證狀態**：**`PASS`**
- **實體驗證真實 Git 案例數**：**32 筆**（100% 通過 `git rev-parse`、`git cat-file -e` 與 Patch 雜湊校驗）
- **無效/失聯案例數 (Ineligible)**：**0 筆**
- **真實配對 (Actual Before/After Pairs)**：**8 對（16 筆）**（Before 為漏洞 commit，After 為修復 commit，兩端皆為真實 Git 位元組）
- **真實單一歷史提交 (Real Single Commits)**：**16 筆**（真實良性工程提交）
- **受控物理案例 (Controlled Physical Stratum)**：**220 筆**（成對受控實驗，完全獨立隔離，不混入真實歷史）
- **總語料規模**：**252 筆**

---

## 四、分層評估結果（Stratified Evaluation Results）

維持 Guard A, B, C, D 程式碼完全未變，在分層語料庫上的實測成果如下：

```
==========================================================================================
STRATIFIED SOURCE-BOUND EVALUATION RESULTS
==========================================================================================

--- STRATUM: REAL_NEXUS_HISTORY (N = 21: 5 HIGH / 16 LOW | Unique FP: 12) ---
Comparator                     | Catch %  | Miss  | FP %     | Pass %   | Pair Acc %
--------------------------------------------------------------------------------
Guard A (Current Whitelist)    |    0.0% | 5     |    0.0% |  100.0% |      0.0%
Guard B (R2 Regex)             |   60.0% | 2     |   68.8% |   31.2% |      0.0%
Guard C (R3 Flat Facts)        |   60.0% | 2     |   68.8% |   31.2% |      0.0%
Guard D (Semantic Candidate)   |    0.0% | 5     |    0.0% |  100.0% |      0.0%

--- STRATUM: REAL_EXTERNAL_SECURITY_HISTORY (N = 11: 3 HIGH / 8 LOW | Unique FP: 6) ---
Comparator                     | Catch %  | Miss  | FP %     | Pass %   | Pair Acc %
--------------------------------------------------------------------------------
Guard A (Current Whitelist)    |    0.0% | 3     |    0.0% |  100.0% |      0.0%
Guard B (R2 Regex)             |  100.0% | 0     |  100.0% |    0.0% |      0.0%
Guard C (R3 Flat Facts)        |  100.0% | 0     |  100.0% |    0.0% |      0.0%
Guard D (Semantic Candidate)   |    0.0% | 3     |    0.0% |  100.0% |      0.0%

--- STRATUM: CONTROLLED_PHYSICAL (N = 220: 110 HIGH / 110 LOW | Unique FP: 29) ---
Comparator                     | Catch %  | Miss  | FP %     | Pass %   | Pair Acc %
--------------------------------------------------------------------------------
Guard A (Current Whitelist)    |    0.0% | 110   |    0.0% |  100.0% |      0.0%
Guard B (R2 Regex)             |   57.3% | 47    |   36.4% |   63.6% |     20.9%
Guard C (R3 Flat Facts)        |   85.5% | 16    |   55.5% |   44.5% |     30.0%
Guard D (Semantic Candidate)   |   77.3% | 25    |    0.0% |  100.0% |     77.3%

--- STRATUM: OVERALL (N = 252: 118 HIGH / 134 LOW | Unique FP: 45) ---
Comparator                     | Catch %  | Miss  | FP %     | Pass %   | Pair Acc %
--------------------------------------------------------------------------------
Guard A (Current Whitelist)    |    0.0% | 118   |    0.0% |  100.0% |      0.0%
Guard B (R2 Regex)             |   58.5% | 49    |   44.0% |   56.0% |     19.5%
Guard C (R3 Flat Facts)        |   84.7% | 18    |   59.7% |   40.3% |     28.0%
Guard D (Semantic Candidate)   |   72.0% | 33    |    0.0% |  100.0% |      72.0%
```

---

## 五、關鍵科學發現：為什麼 Guard D 在真實歷史層中完全失效？

在真實歷史層（`REAL_NEXUS_HISTORY` 與 `REAL_EXTERNAL_SECURITY_HISTORY`）共 8 個真實的高風險歷史漏洞提交中，**Guard D 攔截了 0 個（Catch Rate = 0.0%，Misses = 8/8）**。

### 漏報根本原因（Root Cause Analysis）：
1. **物件導向與現代抽象封裝（Path/FS Abstractions）**：
   - *案例*：`nexus-runtime` 的 `eeb147a`（ExecutionStateStore 路徑遍歷）。
   - *成因*：真實代碼並未使用純文字的 `open(os.path.join(...))`，而是使用 `self.state_dir / f"{task_id}.json"` 與 `path.read_text()`。Guard D 現有的 AST 與正則僅檢查 `open()` 關鍵字與 `os.path.basename`，對 `pathlib.Path` 的運算子多載完全盲目。
2. **非 Shell 的語意隔離缺陷（Process Isolation Semantics）**：
   - *案例*：`Nexus-new` 的 `09c9afc64`（Wiki 審計 Subprocess 隔離）。
   - *成因*：真實代碼調用 `subprocess.run(argv, cwd=repo_root)` 時，使用的是乾淨的陣列呼叫（`argv: list[str]`），**完全沒有 `shell=True`**！漏洞在於它未將執行目錄拷貝至臨時隔離區，導致審計副作用污染主倉庫。Guard D 僅將 `shell=True` 視為高風險，對非 Shell 但缺乏隔離的行程呼叫完全放行。
3. **工作流與供應鏈語意依賴（CI & Supply Chain Semantics）**：
   - *案例*：`nexus-core` 的 `609c503`（GitHub Action 未鎖定 commit SHA）與 `Nexus-new` 的 `24b4e4815`（Gitlink 憑證未過濾）。
   - *成因*：真實工作流安全問題在於 Action 標籤（如 `actions/checkout@v4` vs SHA-256）與 Gitlink 憑證洩漏，而非 Guard D 規則庫中死板的 `npm publish` 或 `docker.sock`。
4. **非 Python 語言支援缺失（Language Scope）**：
   - *案例*：`devspace` 的 `5d37965`（Cutover 輸入驗證缺乏）。
   - *成因*：DevSpace 為 TypeScript 專案（`src/cli.ts`），Guard D 的 AST 解析器（`ast.parse`）僅支援 Python，對 TypeScript 僅能退化為表面正則，無法進行結構分析。
5. **深層邏輯與演算法 DoS（Algorithmic & Parsing Flaws）**：
   - *案例*：PyYAML `34a9bf8`（YAML Merge Key 指數放大 DoS）與 Werkzeug `f54fe98`（Windows 裝置名稱路徑解析缺陷）。
   - *成因*：真實歷史漏洞是函式庫內部的深層邏輯缺陷（遞迴引用放大、特殊的 OS 命名空間解析），不可能被一般的語法層級 Guard D 靜態規則捕捉。

### 對比觀察（Guard B / C 的假性攔截）：
- Guard B 與 C 在真實歷史層雖然看似有攔截率（60% ~ 100%），但代價是**在良性歷史代碼上產生了 68.8% 至 100.0% 的災難性誤報**（將所有常規的單元測試、文檔更新、依賴設定全數阻斷）。
- Guard D 雖然保證了 **0.0% 的良性誤報**，但在真實歷史漏洞面前，其「語法糖正則與簡化 AST」立刻暴露出只適用於**人造範例（Toy Examples）**的本質局限。

---

## 六、判定決策：候選資格否決與降級標定

依據第 19 條決策條件：
- [x] A. Guard D frozen source 未變（SHA256: `696b0923e1...` 嚴格吻合）
- [x] B. 來源綁定機器證明驗證 PASS（32 筆真實 Git commit/blob 100% 驗證通過）
- [ ] **C. real-history strata 仍顯示實質 incremental safety value（FAIL：在真實歷史 High-Risk 上攔截率為 0.0%）**
- [x] D. false positive burden 在 real-history evidence 可接受（PASS：0.0% 誤報）
- [ ] **E. 結果不由少數 duplicated family 支配（FAIL：原有高表現完全由 220 筆受控物理題庫所支撐）**

因此，嚴格拒絕「用受控合成數據掩蓋真實歷史失效」的自欺行為，Guard D 正式被定性為：
$$\mathbf{DETERMINISTIC\_SEMANTIC\_GUARD\_RESEARCH\_PROTOTYPE\_ONLY}$$
（不得標定為 `DETERMINISTIC_SEMANTIC_GUARD_CANDIDATE_PROPOSAL_READY`）。

---

## 七、全景權威矩陣 V2（SEMANTIC_GUARD_AUTHORITY_MATRIX_V2）

全面審查六大倉庫的現有架構定位與合約邊界：

| 評估維度 | nexus-core | Nexus-new | nexus-runtime | nexus-open-swe-runtime | devspace | nexus-opencli-reviewer |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **現有權威合約定位** | 嚴格限定：Evidence Trust Core 與 Completion Core。明訂不擁有 Agent 執行或自動修復。 | 明確定位：**Legacy Integration Lab & Compatibility Host**。已非 Core/Learning/Runtime 的 Canonical 倉庫。 | 獨立封裝：任務編排、重試/狀態、事件與寫入邊界、AST 輔助。不擁有 Open SWE 執行。 | 執行運行時：語意執行、診斷、有界修復、模型傳輸、工具執行。無治理權威。 | 本地工具機制：MCP Host 工具封裝、工作區狀態、行程會話、Subagent 協調。 | 研究原型與評估：專注評估與基準測試，無生產安全 SSOT 權威。 |
| **A. Policy Semantics Owner** | ❌ 嚴禁 | ❌ 已降級為 Lab | ⚠️ 僅接收注入 Policy | ❌ 無策略定義權 | ❌ 僅負責 Tooling 機制 | ❌ 僅為離線研究 |
| **B. Policy Config Owner** | ❌ | ⚠️ 歷史殘留 | ⚠️ 執行參數 | ❌ | ⚠️ 本地 workspace 設定 | ❌ |
| **C. Enforcement Contract Owner** | ❌ | ⚠️ | ✅ **首選（Ports & Boundaries）** | ⚠️ | ⚠️ | ❌ |
| **D. Physical Enforcement Owner** | ❌ | ❌ | ⚠️ 次要 | ✅ **首選（Open SWE Worker）** | ✅ **首選（MCP Tool Host）** | ❌ |
| **E. Evidence/Receipt Producer** | ✅ Completion Receipt | ⚠️ | ✅ State/Event Receipt | ✅ Model Invocation Receipt | ✅ Execution Receipt | ⚠️ Benchmark Receipt |
| **F. Verifier/Certifier Consumer** | ✅ **唯一核證者** | ❌ | ❌ | ❌ | ❌ | ❌ |

### 權威歸屬最終裁定：
$$\mathbf{SEMANTIC\_GUARD\_NEW\_OWNER\_RECOMMENDED}$$

### 裁定理由與架構分工：
1. **現有六大倉庫無一具備安全策略語意 SSOT**：
   - `nexus-core` 職責已被嚴格限縮在 Evidence Trust 與 Completion Certification，硬塞安全策略會破壞極簡可信核心。
   - `Nexus-new` 已在 README 中明確降級為 `Legacy Integration Lab & Compatibility Host`，不能再承接新的 Canonical 安全策略權威。
   - `nexus-runtime`、`nexus-open-swe-runtime` 與 `devspace` 屬於不同層次的執行/機制載體，策略必須與機制解耦（Separation of Policy and Mechanism）。
2. **推薦建立全新獨立策略倉庫**：
   - **全新 Canonical 策略倉庫建議**：**`James3014/nexus-guardrails`**（或 `nexus-safety-policy`）。
     - 專職負責：安全語意分類法（Taxonomy）、AST 語意規則、安全白名單、合規設定與驗證器規範。
   - **分層落地合約（Split Contract Architecture）**：
     - **Policy Definition (SSOT)** $\to$ `nexus-guardrails`
     - **Enforcement Boundary Contract** $\to$ `nexus-runtime`（透過標準 `Port` 注入）
     - **Physical Interception Execution** $\to$ `nexus-open-swe-runtime` 與 `devspace`（在工具調用與代碼寫入前攔截）
     - **Completion Evidence Verification** $\to$ `nexus-core`（事後驗證防護攔截 Receipt）

---

## 八、來源綁定驗證強化補遺（Provenance Hardening）

先前的 verifier 只確認 commit 與 Git object 存在，無法排除「blob 存在於 object database、但並非該 commit:path 所引用」的 false green。本輪在不修改 Guard D 的前提下，已將 verifier 強化為逐筆 fresh recomputation：

- `commit_before` / `commit_after`：32/32 identity 驗證。
- `commit_after^1 == commit_before`：32/32 parent relation 驗證。
- `commit:path -> blob`：32/32 以 tree/path 重新解析後與記錄 SHA 一致。
- `content`：32/32 與該 case 宣告的 BEFORE/AFTER blob bytes 一致。
- `patch_sha256`：32/32 由 fresh `git diff commit_before commit_after -- path` bytes 重算一致。
- `diff`：32/32 與 fresh Git diff bytes 一致。
- Actual before/after pair：8/8 結構一致、內容 side 分別為 BEFORE / AFTER。
- Ineligible REAL_GIT_HISTORY：0。

同時修正 `extract_git_single_commit()`：`blob_sha_before` 現在綁定 parent commit 的實際 path blob，`blob_sha_after` 綁定 current commit 的實際 path blob；不再把 before/after 偽裝成同一 SHA。若 parent 尚不存在該 path，使用明確 `ABSENT` 狀態。

新增 `tests/test_deterministic_guard_source_bound.py`，13 個 focused tests 全部通過，包含 wrong path、wrong before/after blob、wrong patch hash、wrong content、wrong diff、wrong before/after commit、swapped content、wrong content side，以及「wrong blob object 確實存在於 repo、但不是該 commit:path」的 hostile negative control。

強化後重新跑完整 source-bound evaluation，結果不變：

- REAL_NEXUS_HISTORY：Guard D `0/5` high-risk catch，`0/16` false positive。
- REAL_EXTERNAL_SECURITY_HISTORY：Guard D `0/3` high-risk catch，`0/8` false positive。
- CONTROLLED_PHYSICAL：Guard D `85/110` high-risk catch，`0/110` false positive。

因此 `DETERMINISTIC_SEMANTIC_GUARD_RESEARCH_PROTOTYPE_ONLY` 結論不是 provenance verifier false green 所造成，維持不變。

---

## 九、終端總結（Terminal Summary）

```yaml
RESEARCH_STATUS:
  F4_RISK_SENSOR: TERMINATED_AND_ARCHIVED
  OLD_320_HOLDOUT: RECLASSIFIED_AS_DSG_MIXED_SYNTHETIC_HOLDOUT_V1
  GUARD_D_SOURCE_HASH: 696b0923e1da2c0726fee509f11dbeab94678e60d4412c36cec708538430e0fb_VERIFIED_FROZEN

SOURCE_BOUND_EVIDENCE:
  PROVENANCE_VERIFIER: PASS_32_REAL_GIT_CASES_COMMIT_PATH_BLOB_CONTENT_DIFF_HASH_VERIFIED
  REAL_NEXUS_HISTORY: 5_HIGH_16_LOW (GUARD_D_CATCH: 0/5 = 0.0%, FP: 0/16 = 0.0%)
  REAL_EXTERNAL_SECURITY_HISTORY: 3_HIGH_8_LOW (GUARD_D_CATCH: 0/3 = 0.0%, FP: 0/8 = 0.0%)
  CONTROLLED_PHYSICAL: 110_HIGH_110_LOW (GUARD_D_CATCH: 85/110 = 77.3%, FP: 0/110 = 0.0%)
  ROOT_CAUSE: Real vulnerabilities use OOP abstractions, unisolated envs, and deep logic flaws not captured by toy regex/AST rules.

CANONICAL_AUTHORITY_DISCOVERY:
  NEXUS_CORE: EXCLUDED (Evidence Trust & Completion Core only)
  NEXUS_NEW: EXCLUDED (Legacy Integration Lab only)
  NEXUS_RUNTIME: ENFORCEMENT_BOUNDARY_ONLY
  NEXUS_OPEN_SWE_RUNTIME: PHYSICAL_EXECUTION_ONLY
  DEVSPACE: TOOLING_MECHANICS_ONLY
  NEXUS_OPENCLI_REVIEWER: RESEARCH_ONLY
  AUTHORITY_FINDING: SEMANTIC_GUARD_NEW_OWNER_RECOMMENDED (Recommend dedicated nexus-guardrails repo)

TERMINAL_DETERMINATION: DETERMINISTIC_SEMANTIC_GUARD_RESEARCH_PROTOTYPE_ONLY
```
