# DSG_E3_ADAPTER_BUDGET_V1

## 1. Principles
An adapter connects a subject implementation to the generic runtime verifier kernel.
To prevent the adapter from "cheating" by implementing custom vulnerability detectors or hardcoding test answers, strict budget limits and architectural boundaries are frozen here.

## 2. Quantitative Budget Caps
- **Maximum Logical Lines of Code (LOC)**:
  - Subject Adapter: `<= 60 LOC` (excluding comments and docstrings).
  - Normalization Hooks: `<= 30 LOC`.
  - Violations above 60 LOC trigger `ADAPTER_COMPLEXITY_EXCEEDED`.

## 3. Permitted Adapter Responsibilities
- Intercepting input parameters at subject entry points.
- Normalizing subject parameters into the generic `RuntimeEvent` schema (`FS_RESOLVE`, `FS_EFFECT`, `PROC_EXEC`, `VALIDATE_ORDER`, `PROTECTED_EFFECT`).
- Forwarding events to `GenericRuntimeVerifierKernel.process_event()`.
- Performing physical cleanup of ephemeral test directories.

## 4. Strictly Forbidden Adapter Anti-Patterns
- Embedded Security Policies: Adapter must NOT decide whether an operation is safe or vulnerable.
- Case Branching: Adapter must NOT contain `if case_id == ...` or branch on commit SHAs.
- Expected Verdict Hardcoding: Adapter must NOT contain assertions on expected `PASS` or `VIOLATION` outcomes.
- Heuristic Emulation: Adapter must NOT perform regex matching on source code or inspect git diffs.
- Kernel Bypassing: Adapter must NOT directly return verdict strings without invoking the kernel.
