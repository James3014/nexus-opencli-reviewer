# DSG_E3_PHYSICAL_REPLAY_RECOVERY_PROTOCOL_V1

## 1. Principles of Physical Replay
To resolve the synthetic model defect identified in the first-pass DSG-E3 evaluation, all evaluations under this protocol must:
1. Extract authentic historical source bytes directly from Git objects at exact `commit_before` and `commit_after`.
2. Physically materialize the subject files into sandboxed ephemeral staging roots.
3. Import and execute the actual subject callables directly.
4. Hook only the low-level effect and validation boundaries (e.g. filesystem resolution, subprocess execution, state mutation).
5. Strictly prohibit hand-crafted `before()` or `after()` functions that re-model bug semantics.

## 2. Denominator Hardening (Exact 6/6 HIGH and 6/6 Benign)
The denominator is strictly fixed to all 6 cases declared in `DSG_E3_RUNTIME_HOLDOUT_SELECTION_PROTOCOL_V1`:
- RV1-A: `holdout-rv1-taskservice-6f0a50c`
- RV1-B: `holdout-rv1-projection-c8e7c50`
- RV2-A: `holdout-rv2-sandbox-c35be47`
- RV2-B: `holdout-rv2-cleanup-346f581`
- RV3-A: `holdout-rv3-fencing-56335f7`
- RV3-B: `holdout-rv3-shutdown-22a5ebf`

Along with all 6 benign controls:
- `benign-rv1-nested-valid`
- `benign-rv1-symlink-safe`
- `benign-rv2-temp-isolated`
- `benign-rv2-readonly-root`
- `benign-rv3-precondition-pass`
- `benign-rv3-precondition-fail-clean`

## 3. Physical Execution Witness Contract
Every executed subject must produce an `ACTUAL_SUBJECT_EXECUTION_WITNESS` recording:
- Target repository and commits (`commit_before`, `commit_after`).
- Target file path and blob SHA.
- Materialized file SHA-256.
- Actual callable name and runtime module identity.
- Intercepted effect boundary and event trace.
- Target branch execution confirmation.
