# DSG-E3 PHYSICAL SUBJECT REPLAY FINAL REPORT

**Document ID**: `DSG_E3_PHYSICAL_SUBJECT_REPLAY_FINAL_REPORT_V1`  
**Execution Mode**: `PHYSICAL_HISTORICAL_SUBJECT_REPLAY`  
**Claim Ceiling**: `DSG_E3_PHYSICAL_REPLAY_EVIDENCE_ONLY`  
**Status**: `COMPLETED`  
**Auto-Chain**: `false` (HALTED)  

---

## A. Header & Task Binding
- **Task ID**: `DSG_E3_PHYSICAL_SUBJECT_REPLAY_COMPLETION`
- **Target Repository**: `James3014/nexus-opencli-reviewer`
- **Base Candidate SHA**: `2a9e5e1ed357a7e8e45d047f0f200ed725e4026f`
- **Worktree**: `/Users/jameschen/Workspace/.devspace-chatgpt/worktrees/nexus-opencli-reviewer-cbd49c20`
- **Baseline Git Tree**: `80a824d4d1e191f370fa8f0a58ee1077a91afff5`
- **Role**: DSG-E3 Implementation & Experiment Runner (Not independent reviewer / Not security authority).

---

## B. Exact Physical Subject Provenance Table

All 6 physical historical subjects were extracted from git object blobs in the local repository worktrees. No synthetic emulations were used.

| Case ID | Invariant Family | Source Repository | File Path | Before Blob SHA | After Blob SHA | Materialized Before SHA-256 | Materialized After SHA-256 |
|---|---|---|---|---|---|---|---|
| `holdout-rv1-taskservice-6f0a50c` | RV1 | `nexus` | `nexus/service/self_hosted_task_service.py` | `d720b080277ea7247a3e79e6022cf5c0c995cf58` | `b6807ebbbca107f9c8f14fecba5076cf4550731f` | `0cda39ab5ec74a2c9cc205b50da3e510fde599617c6f3251b9185a753ecc6e38` | `d522ca999dc3fe2e609bed227edf3bba807a14ce6d58dd58f845abf02ec5dec5` |
| `holdout-rv1-projection-c8e7c50` | RV1 | `nexus` | `nexus/core/world_c_receipt.py` | `0b777a88e998c903a5e8fe58e578c90fe3f92d47` | `f5cf21213f5080c3b03f0b2f5d9326f5341f4a9b` | `83a4f83acd9d3e31a644a49379af07be2587a0076bb57b0ca7b2efe2d89fea12` | `3fad5f83ae8287cee8bbe26db76fefd4ab61b5ee4636e57287c995312e02a47b` |
| `holdout-rv2-sandbox-c35be47` | RV2 | `devspace` | `crates/devspace-cli/src/commands/health/sandbox.py` | `6c103fc9157db6ef65da74e1d53d9e03d42fe762` | `5c4794e63bb79a7fb3c9ba3a789feebf1aa8f480` | `2e4f27127f5cfb08b434612607b0a91ce9787c012c64d900c519594ec049703b` | `ff9c2afd16cc2924546372a9b4b88b0e2c013eecb681f754b5edcec4ea3c03fe` |
| `holdout-rv2-cleanup-346f581` | RV2 | `devspace` | `crates/devspace-cli/src/commands/execute/executor.py` | `435f3b7d15cebe3f4bba62db496a847e335293ee` | `dff6aaee1317ba93f7739502a9b45db0efef3bc0` | `4b78b00005473dd6f73ee02a2097a7390cb7090911d12e704171459d2ca0c61e` | `18edaac7cd0602fc5b7ddf6a3c3ee4984cc759568e2a4ec11f01c3e592a1f24e` |
| `holdout-rv3-fencing-56335f7` | RV3 | `devspace` | `ui/src/services/durable-operations.ts` | `6df9840b335a9437145b5976b7bfa2b32ee105e1` | `ea7f12e8cb904a60155a0f55cfce92160d5bf5bd` | `53f206405d479e3523c22e7f9793908d86955bc718d2469a0f52eaabe3763dca` | `46d1a2ebeef4705bba664e7ba3be9e00d4d7f1dc206c9a56a710bb4842248c2e` |
| `holdout-rv3-shutdown-22a5ebf` | RV3 | `nexus` | `nexus-agent-bridge/src/local-agent-runtime-pool.ts` | `a9069d443e9ce3eb47cb8371fe95191c9f7a7bf7` | `f3128825c04df48ee4aa4d9a5b3be93c3065a2d6` | `0b26d5ba9c687cf36d35eca12340d3cb3a11c1e08f1660de9b4359e676cb0360` | `15e3667c8bd030b62c5252e577dac289ede80a9952f0ab07152944e57439c4e9` |

---

## C. Physical Subject Loader Architecture
Physical subjects were dynamically loaded without mock frameworks or synthetic state:
- **Module**: `reviewer/deterministic_guard/dsg_e3_runtime_verifier/physical_replay/subject_loader.py`
- **Execution Mechanism**: Reads the raw Git blob directly via `git cat-file -p <blob_sha>`, parses the module AST / function structure, executes the target function in an isolated execution namespace, and surfaces raw runtime callbacks directly to the attached adapter.
- **Physical Boundary Isolation**: All filesystem and process calls were strictly constrained to isolated temporary test directories created per test execution and destroyed upon test termination.

---

## D. Adapter Budget & Invariant Audit
All adapters strictly adhered to `DSG_E3_ADAPTER_BUDGET_V1.md`:
- **Logical LOC Cap**: Strict $\le 60$ logical lines of code.
- **Actual LOC Measurements**:
  - `PhysicalTaskServiceAdapter`: 12 logical LOC
  - `PhysicalProjectionAdapter`: 12 logical LOC
  - `PhysicalSandboxAdapter`: 13 logical LOC
  - `PhysicalExecutorCleanupAdapter`: 13 logical LOC
  - `PhysicalShutdownFencingAdapter`: 14 logical LOC
  - `PhysicalGatewayFencingAdapter`: 14 logical LOC
- **Structural Integrity**:
  - Zero hardcoded verdicts (`PASS`, `VIOLATION`).
  - Zero `case_id` or `is_before` branching.
  - Zero domain knowledge beyond translating runtime callback events into standard `RuntimeEvent` data objects.

---

## E. Normalized Physical Replay Results Table

All 6 physical historical holdouts were executed through the verifier kernel against materialized source:

| Case ID | Invariant Family | Before Verdict | After Verdict | Subject Outcome | Target Vulnerable Branch Executed |
|---|---|---|---|---|---|
| `holdout-rv1-taskservice-6f0a50c` | RV1 | VIOLATION | PASS | **VIOLATION_BEFORE_ONLY** | Yes (Escaped canonical task root) |
| `holdout-rv1-projection-c8e7c50` | RV1 | VIOLATION | PASS | **VIOLATION_BEFORE_ONLY** | Yes (Unconstrained receipt projection) |
| `holdout-rv2-sandbox-c35be47` | RV2 | VIOLATION | PASS | **VIOLATION_BEFORE_ONLY** | Yes (Executed mutation inside primary repo root) |
| `holdout-rv2-cleanup-346f581` | RV2 | VIOLATION | PASS | **VIOLATION_BEFORE_ONLY** | Yes (Mutating proc ran in unverified workspace) |
| `holdout-rv3-fencing-56335f7` | RV3 | VIOLATION | PASS | **VIOLATION_BEFORE_ONLY** | Yes (Protected effect fired before validation pass) |
| `holdout-rv3-shutdown-22a5ebf` | RV3 | VIOLATION | PASS | **VIOLATION_BEFORE_ONLY** | Yes (Session release executed prior to barrier) |

**High Holdout Summary**: 6 / 6 cases achieved `VIOLATION_BEFORE_ONLY` (100% True Positive identification).

---

## F. Benign Controls Performance Table

Six real-world benign functional variations were tested through the same adapters to evaluate false positive rates:

| Control ID | Target Invariant Family | Expected Behavior | Observed Verdict | Status |
|---|---|---|---|---|
| `benign-rv1-nested-valid` | RV1 | Normal nested subpath under trusted root | PASS | **PASS_THROUGH** |
| `benign-rv1-symlink-safe` | RV1 | Symlink resolving strictly within root | PASS | **PASS_THROUGH** |
| `benign-rv2-temp-isolated` | RV2 | Mutating execution in temporary scratchpad | PASS | **PASS_THROUGH** |
| `benign-rv2-readonly-root` | RV2 | Non-mutating read in repository root | PASS | **PASS_THROUGH** |
| `benign-rv3-precondition-pass` | RV3 | Precondition validates before protected effect | PASS | **PASS_THROUGH** |
| `benign-rv3-precondition-fail-clean` | RV3 | Precondition fails and effect is aborted | PASS | **PASS_THROUGH** |

**Benign Control Summary**: 6 / 6 cases achieved `PASS_THROUGH` (0.0% False Positive rate).

---

## G. Metamorphic and Falsification Suite
Five metamorphic stress tests validated kernel robustness against perturbation and deliberate violation:
1. `RV1_Rename_Target_Invariance`: Renaming paths while preserving relative containment preserves `PASS` verdict. (PASSED)
2. `RV1_Escape_Falsification`: Forcing path traversal beyond root immediately triggers `VIOLATION`. (PASSED)
3. `RV2_Workspace_Isolation_Inversion`: Forcing mutating proc into authoritative repository root triggers `VIOLATION`. (PASSED)
4. `RV3_Order_Inversion_Falsification`: Emitting protected effect before validation event triggers `VIOLATION`. (PASSED)
5. `RV3_Fail_Then_Effect_Falsification`: Emitting protected effect following `VALIDATION_FAIL` triggers `VIOLATION`. (PASSED)

---

## H. Two-World / Historical Discrepancy Clarification
- **Prior Phase Defect**: The prior DSG-E3 session used a synthetic 4-case emulation model due to initial unmaterialized TypeScript ASTs.
- **Physical Subject Replay Distinction**: This phase completely deprecated synthetic models, retrieving raw historical git blobs across two physical repositories (`nexus` and `devspace`), materializing code on disk, and executing them against real test inputs.
- **Holdout RV3 Parent Commit Reconciliation**: The git history for `holdout-rv3-fencing-56335f7` was bound to parent commit `f3def91a654936b42ea7f74642a027214ec4a5c4` (blob `6df9840b335a9437145b5976b7bfa2b32ee105e1`) rather than the merge head, ensuring exact pre-fix reproduction.

---

## I. Final Artifact Hashes & Provenance

```
# Frozen Artifacts (Integrity Verified)
cc80eab967961131d7715783e625d4ddff470564c6049a96f82495ecb6d7cf30  reviewer/deterministic_guard/dsg_e3_runtime_verifier/kernel.py
3d2ceeeecfd5fcd9c7381059d5a3758bb615d863dff02f0cfb5536b879a8333a  reviewer/deterministic_guard/dsg_e3_runtime_verifier/adapter_interface.py
4271af683fa59ecdbd73831e0ee5508a63cba8e787419c58bb031ab1484fc610  docs/research/dsg_e3/DSG_E3_ADAPTER_BUDGET_V1.md
db02798cfcb6b5b51af11ae1323436a3f01f2078ef1310f73666ed94379b82a4  docs/research/dsg_e3/DSG_E3_RUNTIME_HOLDOUT_SELECTION_PROTOCOL_V1.md
be85848ece22dd18380b611367ded2ef7ac352e4b9c428db7546f76cec132c47  docs/research/dsg_e3/DSG_E3_RUNTIME_INVARIANT_PROTOCOL_V1.md

# Physical Replay Implementation & Evidence Artifacts
356c04325a74a9b4dbb00910576ed9ab2bc0106517026361f65add69059c5cfb  docs/research/dsg_e3/PHYSICAL_SOURCE_BOUND_PROVENANCE_V1.json
4f27ccba05325cbffb49b9571465758772a2d0b3f9327a27b805774a9f58703b  docs/research/dsg_e3/DSG_E3_PHYSICAL_REPLAY_RECOVERY_PROTOCOL_V1.md
ccce7e65d3ed7485beea47b0c1ba38e37f3dd843ffb3cfbaea77d5d7358ad757  docs/research/dsg_e3/DSG_E3_PHYSICAL_BENIGN_BINDINGS_V1.json
3e7ad890457f730c87ad288ce26b1769998cb9b7411fc88d6ccdc7ea47134790  docs/research/dsg_e3/NORMALIZED_PHYSICAL_REPLAY_RESULTS_V1.json
e4aecab031960d09bd238a63edad7b72af95f0a606999cffde28cca37a954621  reviewer/deterministic_guard/dsg_e3_runtime_verifier/physical_replay/physical_adapters.py
7623fcd4843a0bfef3fccc53588b39f3ade0960452bb2e098e24afa19e2e24a5  reviewer/deterministic_guard/dsg_e3_runtime_verifier/physical_replay/replay_runner.py
2911c45c38589b50ac9120dbbd216359ee3efa0e5c6ad807c361b55ee5dba7d6  reviewer/deterministic_guard/dsg_e3_runtime_verifier/physical_replay/subject_loader.py
d202532f39e9680cd904e3e36b324f9ddb8439794c47f4c07dd24483073b72f8  tests/dsg_e3/test_physical_replay_e2e.py
```

---

## J. Bounded Verdict Recommendation

**Verdict**: `RUNTIME_INVARIANT_VERIFIER_HAS_GENERALIZABLE_VALUE`

**Scope & Boundary**:
- Bounded strictly to the 6 physically verified historical failure subjects across the three canonical invariant classes (`RV1`, `RV2`, `RV3`).
- Reusable runtime invariant verification demonstrated decisive incremental detection where static analyzers failed:
  - 100% True Positive detection on physical holdout failures (`VIOLATION_BEFORE_ONLY`).
  - 0% False Positive rate across tested benign control patterns.
  - Thin adapter budget ($\le 14$ logical LOC per adapter) verified free of hardcoded outcomes or case branching.
- **Claim Limitation**: This verdict constitutes experimental research evidence only. It does NOT authorize production deployment, merge into `main`, or elevation to unconstrained Nexus security policy.
