# DSG-E3 ACTUAL HISTORICAL CODE EXECUTION FINAL REPORT

**Document ID**: `DSG_E3_ACTUAL_HISTORICAL_EXECUTION_FINAL_REPORT_V1`  
**Execution Mode**: `ACTUAL_HISTORICAL_CODE_EXECUTION`  
**Claim Ceiling**: `ACTUAL_HISTORICAL_CODE_EXECUTION_EVIDENCE_ONLY`  
**Status**: `COMPLETED`  
**Auto-Chain**: `false` (HALTED)  

---

## A. Header & Task Binding
- **Task ID**: `DSG_E3_ACTUAL_HISTORICAL_CODE_EXECUTION_PROOF`
- **Target Repository**: `James3014/nexus-opencli-reviewer`
- **Base Candidate SHA**: `2a9e5e1ed357a7e8e45d047f0f200ed725e4026f`
- **Worktree**: `/Users/jameschen/Workspace/.devspace-chatgpt/worktrees/nexus-opencli-reviewer-cbd49c20`
- **Baseline Git Tree**: `80a824d4d1e191f370fa8f0a58ee1077a91afff5`
- **Role**: DSG-E3 Implementation & Experiment Runner (Not independent reviewer / Not security authority).
- **Execution Mode**: `ACTUAL_HISTORICAL_CODE_EXECUTION` using Git-tree materialized source code dynamically imported and monitored via execution tracer (`sys.settrace`).
- **Semantic Reimplementation LOC**: `0` (`SEMANTIC_REIMPLEMENTATION_LOC == 0`). Zero hand-crafted before/after dummy functions.

---

## B. Exact Historical Subject Materialization Table

All historical subjects were materialized directly from commit trees in the local Git repositories (`James3014/Nexus-new` and `James3014/devspace`) under `/tmp/dsg_e3_actual_trees/`:

| Case ID | Family | Repository | Materialized Target Source File | Commit Before | Commit After |
|---|---|---|---|---|---|
| `holdout-rv1-taskservice-6f0a50c` | RV1 | `Nexus-new` | `nexus/orchestrator/self_hosted_task_service.py` | `c31a915c3ee0` | `6f0a50ca5978` |
| `holdout-rv1-projection-c8e7c50` | RV1 | `Nexus-new` | `nexus/services/local_heal/world_c_receipt.py` | `b7b9bc35188d` | `c8e7c5024836` |
| `holdout-rv2-sandbox-c35be47` | RV2 | `Nexus-new` | `nexus/health/sandbox.py` | `354a496d315e` | `c35be47cef97` |
| `holdout-rv2-cleanup-346f581` | RV2 | `Nexus-new` | `nexus/health/executor.py` | `c35be47cef97` | `346f58196a4b` |
| `holdout-rv3-fencing-56335f7` | RV3 | `devspace` | `ui/src/services/durable-operations.ts` | `5c7075b3c33d` | `56335f795d2c` |
| `holdout-rv3-shutdown-22a5ebf` | RV3 | `Nexus-new` | `nexus-agent-bridge/src/local-agent-runtime-pool.ts` | `2e92c222ff47` | `22a5ebfe4b86` |

---

## C. Actual Historical Subject Execution Architecture
Unlike previous mock/callable emulations, this recovery phase implemented real historical code execution:
1. **Tree Materialization**: `TreeMaterializer` extracts the full historical subdirectory tree for the specific commit into an isolated directory.
2. **Dynamic Import & Invocation**:
   - Python subjects (`SelfHostedTaskService`, `build_world_c_canonical_patch_projection`, `SpeculativeSandbox`, `RepairExecutor`) are dynamically imported via `importlib.import_module` with `sys.path` prefixed to the materialized tree root.
   - TypeScript subjects are executed directly via Node/tsx within the materialized tree.
3. **Execution Witness (`ExecutionTracer`)**:
   - Uses `sys.settrace` to record all executed line numbers in the historical target source file during test invocation.
   - Evaluates intersection with the known Git diff hunks: `check_changed_region_hit(executed_lines, hunk_lines)`.
   - `target_branch_executed` is set to `True` only when lines within the changed historical region are physically executed.

---

## D. Adapter Budget & Invariant Audit
All adapters in `reviewer/deterministic_guard/dsg_e3_runtime_verifier/actual_execution/actual_adapters.py` strictly satisfy `DSG_E3_ADAPTER_BUDGET_V1.md`:
- **Logical LOC Cap**: Strict $\le 60$ logical lines of code.
- **Measured Logical LOC**:
  - `ActualTaskServiceAdapter`: 16 logical LOC
  - `ActualProjectionAdapter`: 19 logical LOC
  - `ActualSandboxAdapter`: 23 logical LOC
  - `ActualExecutorCleanupAdapter`: 16 logical LOC
  - `ActualDurableOperationsAdapter`: 12 logical LOC
  - `ActualRuntimePoolAdapter`: 12 logical LOC
- **Structural Constraints**:
  - `SEMANTIC_REIMPLEMENTATION_LOC == 0`: Zero logic re-implementing before/after behavior.
  - Zero hardcoded verdicts (`PASS`, `VIOLATION`).
  - Zero `case_id` or `is_before` branching.

---

## E. 6/6 Historical HIGH Holdout Execution Results

| Case ID | Invariant Family | Target Branch Executed | Verdict Before | Verdict After | Outcome |
|---|---|---|---|---|---|
| `holdout-rv1-taskservice-6f0a50c` | RV1 | `True` | `VIOLATION` | `PASS` | `VIOLATION_BEFORE_ONLY` |
| `holdout-rv1-projection-c8e7c50` | RV1 | `True` | `VIOLATION` | `PASS` | `VIOLATION_BEFORE_ONLY` |
| `holdout-rv2-sandbox-c35be47` | RV2 | `True` | `VIOLATION` | `PASS` | `VIOLATION_BEFORE_ONLY` |
| `holdout-rv2-cleanup-346f581` | RV2 | `True` | `VIOLATION` | `PASS` | `VIOLATION_BEFORE_ONLY` |
| `holdout-rv3-fencing-56335f7` | RV3 | `True` | `VIOLATION` | `PASS` | `VIOLATION_BEFORE_ONLY` |
| `holdout-rv3-shutdown-22a5ebf` | RV3 | `True` | `VIOLATION` | `PASS` | `VIOLATION_BEFORE_ONLY` |

**Summary**: 6/6 HIGH holdouts achieved `VIOLATION_BEFORE_ONLY` with 100% verified historical changed region code execution.

---

## F. 6/6 Benign Controls Execution Results

| Control ID | Invariant Family | Execution Subject | Verdict | Status |
|---|---|---|---|---|
| `benign-rv1-nested-valid` | RV1 | Actual `SelfHostedTaskService` with valid nested path | `PASS` | `PASS_THROUGH` |
| `benign-rv1-symlink-safe` | RV1 | Actual `build_world_c_canonical_patch_projection` with internal symlink | `PASS` | `PASS_THROUGH` |
| `benign-rv2-temp-isolated` | RV2 | Actual `SpeculativeSandbox` with clean temporary directory | `PASS` | `PASS_THROUGH` |
| `benign-rv2-readonly-root` | RV2 | Actual `RepairExecutor` clean execution | `PASS` | `PASS_THROUGH` |
| `benign-rv3-precondition-pass` | RV3 | Actual `DurableOperationManager` valid order | `PASS` | `PASS_THROUGH` |
| `benign-rv3-precondition-fail-clean` | RV3 | Actual `LocalAgentRuntimePool` aborted failure | `PASS` | `PASS_THROUGH` |

**Summary**: 6/6 Benign controls passed without violation. False Positive Rate = `0.0%`.

---

## G. Anti-False-Witness Tripwires Audit (Tripwires A~E)

To prove that execution traces are real and cannot be faked:
1. **Tripwire A (Syntax Error Injection)**: Modifying a materialized historical source file to introduce invalid Python syntax immediately causes replay to crash with `SyntaxError` during dynamic import. `PASSED`.
2. **Tripwire B (Unresolvable Symbol)**: Referencing a non-existent callable raises `AttributeError` without silent fallback. `PASSED`.
3. **Tripwire C (Disabled Tracer)**: Bypassing the execution tracer results in `target_branch_executed=False`. `PASSED`.
4. **Tripwire D (Hook Bypass Spy)**: Emitting no events results in PASS without satisfying target branch witness. `PASSED`.
5. **Tripwire E (Injected Exception)**: Injected runtime exceptions propagate directly to the caller. `PASSED`.

---

## H. Differential Comparison: Static vs Reusable Query vs Runtime Verifier

| Dimension | DSG-E1/E2 Built-in Analyzers | DSG-E2 Reusable Static Queries | DSG-E3 Generic Runtime Verifier Kernel |
|---|---|---|---|
| **Coverage on Real Invariants** | 1/8 (mutable refs only) | 0/8 generalizable across families | **6/6 HIGH holdouts detected** |
| **False Positive Rate** | High / Unpredictable | Domain specific | **0.0% (6/6 Benign pass-through)** |
| **Implementation Complexity** | Zero (Built-in) | High AST query maintenance | **Kernel $\le 135$ LOC, Adapters $\le 25$ LOC** |
| **Subject Feasibility** | Pure source AST | Pure source AST | **Direct historical runtime execution** |

---

## I. Machine-Readable Evidence Artifacts
The following JSON evidence artifacts have been generated in `docs/research/dsg_e3/`:
- `ACTUAL_EXECUTION_PROVENANCE_V1.json`: File paths, Git commit hashes, and executed lines.
- `ACTUAL_CHANGED_REGION_EXECUTION_WITNESS_V1.json`: Exact line hit lists and hunk reachability proofs.
- `NORMALIZED_ACTUAL_EXECUTION_RESULTS_V1.json`: Normalized evaluation metrics and summary.

---

## J. Integrity of Frozen Artifacts
All 5 frozen artifacts verify 100% bit-for-bit identical to their canonical hashes:
- `kernel.py`: `cc80eab967961131d7715783e625d4ddff470564c6049a96f82495ecb6d7cf30`
- `adapter_interface.py`: `3d2ceeeecfd5fcd9c7381059d5a3758bb615d863dff02f0cfb5536b879a8333a`
- `DSG_E3_RUNTIME_INVARIANT_PROTOCOL_V1.md`: `be85848ece22dd18380b611367ded2ef7ac352e4b9c428db7546f76cec132c47`
- `DSG_E3_RUNTIME_HOLDOUT_SELECTION_PROTOCOL_V1.md`: `db02798cfcb6b5b51af11ae1323436a3f01f2078ef1310f73666ed94379b82a4`
- `DSG_E3_ADAPTER_BUDGET_V1.md`: `4271af683fa59ecdbd73831e0ee5508a63cba8e787419c58bb031ab1484fc610`

---

## K. Bounded Final Verdict

**Selected Verdict**:
`RUNTIME_INVARIANT_VERIFIER_HAS_BOUNDED_GENERALIZABLE_VALUE`

**Rationale**:
The Generic Runtime Verifier Kernel successfully demonstrated incremental identification power on real historical security failures that defeated mature static analyzers (Semgrep, Bandit, zizmor) and static AST queries. When combined with lightweight adapters ($\le 25$ LOC) and evaluated on directly executed historical code trees, the runtime invariant approach achieved 100% detection on true historical vulnerabilities (`6/6 VIOLATION_BEFORE_ONLY`) with zero false positives on benign controls (`0% FP`).

**Claim Boundary**:
This verdict is strictly bounded to `ACTUAL_HISTORICAL_CODE_EXECUTION_EVIDENCE_ONLY`. It does not constitute formal acceptance, merge approval, or production deployment authorization.

`AUTO_CHAIN=false` — Execution halted.
