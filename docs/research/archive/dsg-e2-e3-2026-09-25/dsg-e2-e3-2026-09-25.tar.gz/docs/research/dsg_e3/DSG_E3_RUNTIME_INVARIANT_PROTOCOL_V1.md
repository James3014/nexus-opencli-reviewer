# DSG_E3_RUNTIME_INVARIANT_PROTOCOL_V1

## 1. Scope & Authority Binding
- **Protocol ID**: `DSG_E3_RUNTIME_INVARIANT_PROTOCOL_V1`
- **Claim Ceiling**: `RUNTIME_INVARIANT_VERIFIER_PROBE_EVIDENCE_ONLY`
- **Research Question**: Does a generic runtime-invariant verifier kernel coupled with thin subject adapters provide robust, generalizable, low-false-positive discrimination on real-world security failures where static AST analysis fails?

## 2. Invariant Semantics & Verification Contracts

### RV1: TRUSTED_ROOT_CONTAINMENT
- **Contract**:
  $$\forall \text{effect } e \in \text{EffectTrace}, \quad \text{realpath}(e.\text{target}) \subseteq \text{realpath}(e.\text{trusted\_root})$$
- Evaluates canonical resolved target path against trusted root. Rejects directory traversal (`..`), path escaping symlinks, and absolute redirect escapes.

### RV2: ISOLATED_EXECUTION_ROOT
- **Contract**:
  $$\forall \text{exec } p \in \text{ProcessTrace}, \quad p.\text{is\_mutating} \implies (\text{realpath}(p.\text{cwd}) \neq \text{realpath}(p.\text{authoritative\_root}) \land \text{is\_ephemeral}(p.\text{cwd}))$$
- Ensures that mutating subprocesses or tool invocations operate exclusively within an ephemeral workspace or isolated sandbox, never in-place on authoritative source checkouts.

### RV3: VALIDATION_PRECEDES_PROTECTED_EFFECT
- **Contract**:
  $$\text{Trace} = [e_1, e_2, \dots, e_n]$$
  $$\forall e_k = \text{PROTECTED\_EFFECT}, \quad \exists j < k \text{ s.t. } e_j = \text{VALIDATION\_PASS}$$
  $$\forall e_m = \text{VALIDATION\_FAIL}, \quad \nexists l > m \text{ s.t. } e_l = \text{PROTECTED\_EFFECT}$$
- Strictly forbids executing protected actions prior to validation or after validation failure.

## 3. Evaluation Outcome States
- **`VIOLATION_BEFORE_ONLY`**: Before = VIOLATION, After = PASS (True Discriminative Catch).
- **`VIOLATION_AFTER_ONLY`**: Before = PASS, After = VIOLATION (Regressive Noise).
- **`VIOLATION_BOTH`**: Before = VIOLATION, After = VIOLATION (Non-discriminative Noise).
- **`PASS_BOTH`**: Before = PASS, After = PASS (False Negative / Uncaught).
- **`UNSUPPORTED`**: Subject cannot be modeled within runtime event schema.
- **`ERROR`**: Runtime execution or adapter exception.
- **`ADAPTER_COMPLEXITY_EXCEEDED`**: Adapter required > 60 LOC.
