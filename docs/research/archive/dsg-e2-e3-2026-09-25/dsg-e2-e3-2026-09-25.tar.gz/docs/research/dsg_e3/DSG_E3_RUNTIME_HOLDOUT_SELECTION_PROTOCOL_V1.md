# DSG_E3_RUNTIME_HOLDOUT_SELECTION_PROTOCOL_V1

## 1. Objective & Anti-Contamination Mandate
Pre-commits the candidate universe and deterministic selection rule for unseen holdout evaluation cases prior to inspecting holdout test traces.
Strictly excludes:
- Known 8 development cases (`#1` through `#8`).
- All 4 cases observed in DSG-E2 (`43ffd1b`, `cfbcdad`, `8198c8d`, `96c38f9`).

## 2. Invariant Family Assignment Rules
1. **RV1 (Trusted Root Containment)**:
   - Target: Operations resolving paths where external input or symlink indirection can escape trusted root boundaries.
   - Selected Unseen Holdouts:
     - `holdout-rv1-taskservice-6f0a50c`: `James3014/Nexus-new` @ `6f0a50ca5978effc0323d6cd445d5d4824800f45` (`nexus/orchestrator/self_hosted_task_service.py`).
     - `holdout-rv1-projection-c8e7c50`: `James3014/Nexus-new` @ `c8e7c5024836fd66911e1f0f3b54be11661ade44` (`nexus/services/local_heal/world_c_receipt.py`).
2. **RV2 (Isolated Execution Root)**:
   - Target: Processes executing build/test/audit tasks where execution directory or sandbox lifecycle fails to isolate workspace.
   - Selected Unseen Holdouts:
     - `holdout-rv2-sandbox-c35be47`: `James3014/Nexus-new` @ `c35be47cef9730a8ba89702560667e4c9a28c886` (`nexus/health/sandbox.py`).
     - `holdout-rv2-cleanup-346f581`: `James3014/Nexus-new` @ `346f58196a4b0a1282e63d7df1eed3535578fca4` (`nexus/health/executor.py`).
3. **RV3 (Validation Precedes Protected Effect)**:
   - Target: Operations executing protected/privileged effect before checking required preconditions or continuation tokens.
   - Selected Unseen Holdouts:
     - `holdout-rv3-fencing-56335f7`: `James3014/devspace` @ `56335f7` (`src/gateway.ts` or reconciliation lock fence).
     - `holdout-rv3-shutdown-22a5ebf`: `James3014/devspace` @ `22a5ebf3bd1d15a5a0d2216232385ea261d80c0a` (`src/local-agent-runtime-pool.ts`).

## 3. Benign Controls (LOW_RISK) Selection Criteria
At least 6 distinct operational/non-vulnerable operational executions across Nexus repositories:
1. `benign-rv1-nested-valid`: Legitimate multi-segment subpath within configured store root.
2. `benign-rv1-symlink-safe`: Symlink pointing strictly inside trusted root.
3. `benign-rv2-temp-isolated`: Subprocess spawned inside validated ephemeral tempdir with cleanup.
4. `benign-rv2-readonly-root`: Read-only file inspection in repository root without mutation effect.
5. `benign-rv3-precondition-pass`: Operation validating credentials/locks before proceeding to state write.
6. `benign-rv3-precondition-fail-clean`: Operation detecting invalid token and aborting with zero side effects.
