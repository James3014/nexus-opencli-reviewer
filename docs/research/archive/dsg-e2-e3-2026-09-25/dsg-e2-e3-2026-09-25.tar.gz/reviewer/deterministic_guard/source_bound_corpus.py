"""
Source-Bound Evaluation Corpus & Provenance Verifier
Implements:
1. DSGSourceBoundCaseV1 contract
2. Real Git history extraction from local Nexus & cloned OSS repositories
3. verify_source_bound_corpus() machine provenance verifier
4. semantic_fingerprint_v2() distinctness metric
5. Controlled physical stratum isolation
"""
from __future__ import annotations

import ast
import hashlib
import json
import os
import re
import subprocess
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


@dataclass
class DSGSourceBoundCaseV1:
    case_id: str
    source_kind: str  # REAL_GIT_HISTORY | COUNTERFACTUAL_CONTROL | CONTROLLED_PHYSICAL
    stratum: str      # REAL_NEXUS_HISTORY | REAL_EXTERNAL_SECURITY_HISTORY | CONTROLLED_PHYSICAL
    repository_full_name: str
    commit_before: str
    commit_after: str
    path: str
    blob_sha_before: str
    blob_sha_after: str
    patch_sha256: str
    source_url_or_git_identity: str
    risk_truth: str   # HIGH_RISK | LOW_RISK
    truth_provenance: str
    guard_a_disposition: str  # ALLOW | BLOCK
    scenario_family: str
    content: str
    diff: str
    content_side: str = "AFTER"  # BEFORE | AFTER for REAL_GIT_HISTORY; AFTER elsewhere
    action_type: str = "WRITE_FILE"
    matched_pair_id: Optional[str] = None
    is_actual_pair: bool = False
    semantic_fingerprint_v2: str = ""


def compute_semantic_fingerprint_v2(content: str, file_path: str) -> str:
    """
    Advanced semantic fingerprint:
    Extracts call targets, dangerous operation families, control-flow structure,
    sanitizers, and AST signatures.
    """
    call_targets = []
    has_sanitizer = False
    danger_families = []

    # Check dangerous patterns
    if "Popen" in content or "os.system" in content or "posix.system" in content:
        danger_families.append("SHELL_EXEC")
    if "importlib.import_module" in content or "eval(" in content or "exec(" in content:
        danger_families.append("DYNAMIC_CODE")
    if "DROP TABLE" in content or "TRUNCATE" in content:
        danger_families.append("DESTRUCTIVE_SQL")
    if "os.path.join" in content or "open(" in content:
        danger_families.append("FS_IO")
    if "os.path.basename" in content or "safe_join" in content or "Path.resolve" in content:
        has_sanitizer = True

    ast_shape = []
    if file_path.endswith(".py"):
        try:
            tree = ast.parse(content)
            for node in ast.walk(tree):
                if isinstance(node, ast.Call):
                    if isinstance(node.func, ast.Name):
                        call_targets.append(node.func.id)
                    elif isinstance(node.func, ast.Attribute):
                        call_targets.append(node.func.attr)
                elif isinstance(node, (ast.If, ast.For, ast.While, ast.Try)):
                    ast_shape.append(type(node).__name__)
        except SyntaxError:
            pass

    key_features = {
        "ext": Path(file_path).suffix,
        "danger_families": sorted(list(set(danger_families))),
        "calls": sorted(list(set(call_targets)))[:10],
        "has_sanitizer": has_sanitizer,
        "ast_shape": ast_shape[:10],
    }
    raw = json.dumps(key_features, sort_keys=True)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def extract_git_case(
    repo_path: str,
    repo_full_name: str,
    commit_after: str,
    file_path: str,
    risk_truth_before: str,
    risk_truth_after: str,
    scenario_family: str,
    provenance_note: str,
    case_prefix: str,
    stratum: str,
    guard_a_disp: str = "ALLOW",
) -> List[DSGSourceBoundCaseV1]:
    """
    Extracts actual before/after pair from real Git history.
    """
    commit_full = subprocess.run(
        ["git", "-C", repo_path, "rev-parse", commit_after],
        capture_output=True, text=True, check=True
    ).stdout.strip()

    parent = subprocess.run(
        ["git", "-C", repo_path, "rev-parse", f"{commit_full}^1"],
        capture_output=True, text=True, check=True
    ).stdout.strip()

    # Get blob SHAs
    blob_b_out = subprocess.run(
        ["git", "-C", repo_path, "ls-tree", parent, file_path],
        capture_output=True, text=True
    ).stdout.split()
    blob_a_out = subprocess.run(
        ["git", "-C", repo_path, "ls-tree", commit_full, file_path],
        capture_output=True, text=True
    ).stdout.split()

    if len(blob_b_out) < 3 or len(blob_a_out) < 3:
        raise ValueError(f"File {file_path} not found in commits {parent} or {commit_full} in {repo_path}")

    blob_b_sha = blob_b_out[2]
    blob_a_sha = blob_a_out[2]

    # Get content bytes
    content_b = subprocess.run(
        ["git", "-C", repo_path, "cat-file", "-p", blob_b_sha],
        capture_output=True, text=True
    ).stdout
    content_a = subprocess.run(
        ["git", "-C", repo_path, "cat-file", "-p", blob_a_sha],
        capture_output=True, text=True
    ).stdout

    # Get patch diff
    diff_out = subprocess.run(
        ["git", "-C", repo_path, "diff", parent, commit_full, "--", file_path],
        capture_output=True, text=True
    ).stdout
    patch_hash = hashlib.sha256(diff_out.encode("utf-8")).hexdigest()

    pair_id = f"real-pair-{case_prefix}"

    # Before case
    case_b = DSGSourceBoundCaseV1(
        case_id=f"{case_prefix}-before",
        source_kind="REAL_GIT_HISTORY",
        stratum=stratum,
        repository_full_name=repo_full_name,
        commit_before=parent,
        commit_after=commit_full,
        path=file_path,
        blob_sha_before=blob_b_sha,
        blob_sha_after=blob_a_sha,
        patch_sha256=patch_hash,
        source_url_or_git_identity=f"{repo_full_name}@{parent}:{file_path}",
        risk_truth=risk_truth_before,
        truth_provenance=f"{provenance_note} [BEFORE]",
        guard_a_disposition=guard_a_disp,
        scenario_family=scenario_family,
        content=content_b,
        diff=diff_out,
        content_side="BEFORE",
        matched_pair_id=pair_id,
        is_actual_pair=True,
        semantic_fingerprint_v2=compute_semantic_fingerprint_v2(content_b, file_path),
    )

    # After case
    case_a = DSGSourceBoundCaseV1(
        case_id=f"{case_prefix}-after",
        source_kind="REAL_GIT_HISTORY",
        stratum=stratum,
        repository_full_name=repo_full_name,
        commit_before=parent,
        commit_after=commit_full,
        path=file_path,
        blob_sha_before=blob_b_sha,
        blob_sha_after=blob_a_sha,
        patch_sha256=patch_hash,
        source_url_or_git_identity=f"{repo_full_name}@{commit_full}:{file_path}",
        risk_truth=risk_truth_after,
        truth_provenance=f"{provenance_note} [AFTER_FIX]",
        guard_a_disposition=guard_a_disp,
        scenario_family=scenario_family,
        content=content_a,
        diff=diff_out,
        content_side="AFTER",
        matched_pair_id=pair_id,
        is_actual_pair=True,
        semantic_fingerprint_v2=compute_semantic_fingerprint_v2(content_a, file_path),
    )

    return [case_b, case_a]


def extract_git_single_commit(
    repo_path: str,
    repo_full_name: str,
    commit: str,
    file_path: str,
    risk_truth: str,
    scenario_family: str,
    provenance_note: str,
    case_id: str,
    stratum: str,
    guard_a_disp: str = "ALLOW",
) -> DSGSourceBoundCaseV1:
    """Extracts a single historical Git commit case."""
    commit_full = subprocess.run(
        ["git", "-C", repo_path, "rev-parse", commit],
        capture_output=True, text=True, check=True
    ).stdout.strip()

    parent = subprocess.run(
        ["git", "-C", repo_path, "rev-parse", f"{commit_full}^1"],
        capture_output=True, text=True, check=True
    ).stdout.strip()

    blob_before_out = subprocess.run(
        ["git", "-C", repo_path, "ls-tree", parent, file_path],
        capture_output=True, text=True
    ).stdout.split()
    blob_after_out = subprocess.run(
        ["git", "-C", repo_path, "ls-tree", commit_full, file_path],
        capture_output=True, text=True
    ).stdout.split()
    if len(blob_after_out) < 3:
        raise ValueError(f"File {file_path} not found in commit {commit_full} in {repo_path}")

    blob_before_sha = blob_before_out[2] if len(blob_before_out) >= 3 else "ABSENT"
    blob_after_sha = blob_after_out[2]

    content = subprocess.run(
        ["git", "-C", repo_path, "cat-file", "-p", blob_after_sha],
        capture_output=True, text=True, check=True
    ).stdout

    diff_out = subprocess.run(
        ["git", "-C", repo_path, "diff", parent, commit_full, "--", file_path],
        capture_output=True, text=True
    ).stdout
    patch_hash = hashlib.sha256(diff_out.encode("utf-8")).hexdigest()

    return DSGSourceBoundCaseV1(
        case_id=case_id,
        source_kind="REAL_GIT_HISTORY",
        stratum=stratum,
        repository_full_name=repo_full_name,
        commit_before=parent,
        commit_after=commit_full,
        path=file_path,
        blob_sha_before=blob_before_sha,
        blob_sha_after=blob_after_sha,
        patch_sha256=patch_hash,
        source_url_or_git_identity=f"{repo_full_name}@{commit_full}:{file_path}",
        risk_truth=risk_truth,
        truth_provenance=provenance_note,
        guard_a_disposition=guard_a_disp,
        scenario_family=scenario_family,
        content=content,
        diff=diff_out,
        content_side="AFTER",
        semantic_fingerprint_v2=compute_semantic_fingerprint_v2(content, file_path),
    )


def _git_text(repo_root: str, args: List[str]) -> str:
    return subprocess.run(
        ["git", "-C", repo_root, *args],
        capture_output=True,
        text=True,
        check=True,
    ).stdout


def _git_bytes(repo_root: str, args: List[str]) -> bytes:
    return subprocess.run(
        ["git", "-C", repo_root, *args],
        capture_output=True,
        check=True,
    ).stdout


def _blob_at_path(repo_root: str, revision: str, file_path: str) -> Optional[str]:
    probe = subprocess.run(
        ["git", "-C", repo_root, "rev-parse", "--verify", f"{revision}:{file_path}"],
        capture_output=True,
        text=True,
    )
    if probe.returncode != 0:
        return None
    oid = probe.stdout.strip()
    obj_type = subprocess.run(
        ["git", "-C", repo_root, "cat-file", "-t", oid],
        capture_output=True,
        text=True,
    )
    if obj_type.returncode != 0 or obj_type.stdout.strip() != "blob":
        return None
    return oid


def verify_source_bound_corpus(corpus: List[DSGSourceBoundCaseV1], local_repo_roots: Dict[str, str]) -> Dict[str, Any]:
    """
    Recompute source-bound provenance from Git and fail closed on any mismatch.

    A Git object merely existing in the object database is insufficient.  Each
    REAL_GIT_HISTORY record must prove the exact commit -> path -> blob binding,
    content bytes for the claimed side, and parent-to-fix patch bytes/hash.
    """
    real_cases = [case for case in corpus if case.source_kind == "REAL_GIT_HISTORY"]
    invalid_case_ids: set[str] = set()
    reasons: List[str] = []
    checks = {
        "commit_identity": 0,
        "parent_relation": 0,
        "path_blob_binding": 0,
        "content_bytes": 0,
        "patch_hash": 0,
        "diff_bytes": 0,
    }

    def fail(case: DSGSourceBoundCaseV1, reason: str) -> None:
        invalid_case_ids.add(case.case_id)
        reasons.append(f"{case.case_id}: {reason}")

    for case in real_cases:
        repo_root = local_repo_roots.get(case.repository_full_name)
        if not repo_root or not os.path.exists(repo_root):
            fail(case, f"repository root missing for {case.repository_full_name}")
            continue

        try:
            before_commit = _git_text(
                repo_root, ["rev-parse", "--verify", f"{case.commit_before}^{{commit}}"]
            ).strip()
            after_commit = _git_text(
                repo_root, ["rev-parse", "--verify", f"{case.commit_after}^{{commit}}"]
            ).strip()
        except subprocess.CalledProcessError:
            fail(case, "commit identity missing or not a commit")
            continue
        if before_commit != case.commit_before or after_commit != case.commit_after:
            fail(case, "recorded commit identity does not match fresh Git identity")
            continue
        checks["commit_identity"] += 1

        try:
            observed_parent = _git_text(repo_root, ["rev-parse", f"{after_commit}^1"]).strip()
        except subprocess.CalledProcessError:
            fail(case, "commit_after has no resolvable first parent")
            continue
        if observed_parent != before_commit:
            fail(case, f"commit_before is not commit_after^1 (observed {observed_parent})")
            continue
        checks["parent_relation"] += 1

        before_blob = _blob_at_path(repo_root, before_commit, case.path)
        after_blob = _blob_at_path(repo_root, after_commit, case.path)
        expected_before = before_blob if before_blob is not None else "ABSENT"
        expected_after = after_blob if after_blob is not None else "ABSENT"
        if case.blob_sha_before != expected_before:
            fail(
                case,
                f"commit_before:path blob mismatch (recorded {case.blob_sha_before}, observed {expected_before})",
            )
            continue
        if case.blob_sha_after != expected_after:
            fail(
                case,
                f"commit_after:path blob mismatch (recorded {case.blob_sha_after}, observed {expected_after})",
            )
            continue
        checks["path_blob_binding"] += 1

        if case.content_side == "BEFORE":
            if before_blob is None:
                fail(case, "BEFORE content requested but path is absent at commit_before")
                continue
            expected_content = _git_bytes(repo_root, ["cat-file", "-p", before_blob])
            identity_revision = before_commit
        elif case.content_side == "AFTER":
            if after_blob is None:
                fail(case, "AFTER content requested but path is absent at commit_after")
                continue
            expected_content = _git_bytes(repo_root, ["cat-file", "-p", after_blob])
            identity_revision = after_commit
        else:
            fail(case, f"unsupported content_side {case.content_side!r}")
            continue

        if case.content.encode("utf-8") != expected_content:
            fail(case, f"content bytes do not match {case.content_side} commit:path blob")
            continue
        expected_identity = f"{case.repository_full_name}@{identity_revision}:{case.path}"
        if case.source_url_or_git_identity != expected_identity:
            fail(case, "source_url_or_git_identity does not match content side")
            continue
        checks["content_bytes"] += 1

        fresh_diff = _git_bytes(
            repo_root, ["diff", before_commit, after_commit, "--", case.path]
        )
        fresh_patch_sha = hashlib.sha256(fresh_diff).hexdigest()
        if case.patch_sha256 != fresh_patch_sha:
            fail(
                case,
                f"patch_sha256 mismatch (recorded {case.patch_sha256}, observed {fresh_patch_sha})",
            )
            continue
        checks["patch_hash"] += 1

        if case.diff.encode("utf-8") != fresh_diff:
            fail(case, "stored diff bytes do not match fresh parent-to-fix git diff")
            continue
        checks["diff_bytes"] += 1

    pair_groups: Dict[str, List[DSGSourceBoundCaseV1]] = {}
    for case in real_cases:
        if case.is_actual_pair:
            if not case.matched_pair_id:
                fail(case, "actual before/after case is missing matched_pair_id")
                continue
            pair_groups.setdefault(case.matched_pair_id, []).append(case)

    pair_verified_count = 0
    pair_invalid_count = 0
    for pair_id, members in pair_groups.items():
        pair_errors: List[str] = []
        if len(members) != 2:
            pair_errors.append(f"expected 2 members, found {len(members)}")
        else:
            left, right = members
            for field in (
                "repository_full_name",
                "commit_before",
                "commit_after",
                "path",
                "patch_sha256",
            ):
                if getattr(left, field) != getattr(right, field):
                    pair_errors.append(f"{field} differs across pair")
            sides = {left.content_side, right.content_side}
            if sides != {"BEFORE", "AFTER"}:
                pair_errors.append(f"pair content sides are {sorted(sides)}")

        if pair_errors:
            pair_invalid_count += 1
            for member in members:
                fail(member, f"pair {pair_id} invalid: {'; '.join(pair_errors)}")
        else:
            pair_verified_count += 1

    ineligible_count = len(invalid_case_ids)
    verified_count = len(real_cases) - ineligible_count
    return {
        "status": "PASS" if ineligible_count == 0 and pair_invalid_count == 0 else "FAIL",
        "verified_count": verified_count,
        "ineligible_count": ineligible_count,
        "ineligible_case_ids": sorted(invalid_case_ids),
        "pair_verified_count": pair_verified_count,
        "pair_invalid_count": pair_invalid_count,
        "checks": checks,
        "reasons": reasons,
    }
