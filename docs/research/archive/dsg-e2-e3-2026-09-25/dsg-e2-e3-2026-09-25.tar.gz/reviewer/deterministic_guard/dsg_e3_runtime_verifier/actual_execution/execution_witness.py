"""
Execution Witness and Tracer (DSG-E3 Actual Historical Execution Proof)

Captures:
- Real line hits during actual module/function execution via sys.settrace.
- Call stack verification to prove the effect was emitted by the actual subject code.
- Verification that target changed-region lines were reached.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import inspect
import os
from pathlib import Path
import sys
from typing import Any, Callable, Dict, List, Optional, Set, Tuple


@dataclass
class LineExecutionWitness:
    file_path: str
    executed_lines: Set[int] = field(default_factory=set)
    call_stacks: List[List[str]] = field(default_factory=list)


class ExecutionTracer:
    """Uses sys.settrace to track exact executed line numbers in target source files."""

    def __init__(self, target_file_path: Path):
        self.target_file_path = os.path.realpath(str(target_file_path))
        self.target_file_raw = str(target_file_path)
        self.executed_lines: Set[int] = set()
        self.recorded_stacks: List[List[str]] = []
        self._prev_trace: Optional[Callable] = None

    def __enter__(self):
        self._prev_trace = sys.gettrace()
        sys.settrace(self._trace_call)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        sys.settrace(self._prev_trace)

    def _trace_call(self, frame, event, arg):
        if event == 'call':
            co_filename = str(Path(frame.f_code.co_filename).resolve())
            if co_filename == self.target_file_path or os.path.realpath(frame.f_code.co_filename) == self.target_file_path or frame.f_code.co_filename == self.target_file_raw:
                return self._trace_line
        return None

    def _trace_line(self, frame, event, arg):
        if event == 'line':
            self.executed_lines.add(frame.f_lineno)
        return self._trace_line
def check_changed_region_hit(
    executed_lines: Set[int],
    target_hunk_lines: Set[int],
) -> bool:
    """Return True if any of the target hunk lines were executed."""
    return bool(executed_lines.intersection(target_hunk_lines))
