"""
Evaluation Runner for DSG-E3 Runtime Verifier Probe

Executes development anchors, unseen holdouts, benign controls, and metamorphic probes.
Outputs normalized results compliant with DSG_E3_RUNTIME_INVARIANT_PROTOCOL_V1.
"""
from __future__ import annotations

import json
import os
import shutil
import tempfile
from pathlib import Path
from typing import Any, Dict, List

from reviewer.deterministic_guard.dsg_e3_runtime_verifier.dev_adapters import (
    DevCase1StoreAdapter,
    DevCase2WikiGateAdapter,
    DevCase5CutoverAdapter,
)
from reviewer.deterministic_guard.dsg_e3_runtime_verifier.holdout_adapters import (
    HoldoutRV1ProjectionAdapter,
    HoldoutRV1TaskServiceAdapter,
    HoldoutRV2SandboxAdapter,
    HoldoutRV3ShutdownAdapter,
)
from reviewer.deterministic_guard.dsg_e3_runtime_verifier.kernel import (
    EventType,
    GenericRuntimeVerifierKernel,
    InvariantVerdict,
    RuntimeEvent,
)


def run_full_evaluation() -> Dict[str, Any]:
    kernel = GenericRuntimeVerifierKernel()

    results = {
        "development_results": [],
        "unseen_holdout_results": [],
        "benign_control_results": [],
        "metamorphic_results": [],
    }

    # =========================================================================
    # 1. DEVELOPMENT ANCHORS (Case #1, #2, #5) - DEVELOPMENT_ONLY
    # =========================================================================

    # Case #1: nexus-rt-store-eeb147a (Path containment)
    with tempfile.TemporaryDirectory() as td:
        state_dir = Path(td) / "state"
        state_dir.mkdir()

        # Before mock: naive state_path concatenating task_id without validation
        class StoreBefore:
            def __init__(self, state_dir, validate_writes=False):
                self.state_dir = state_dir
            def state_path(self, task_id):
                return self.state_dir / f"{task_id}.json"

        # After mock: state_path validates task_id and containment
        class StoreAfter:
            def __init__(self, state_dir, validate_writes=False):
                self.state_dir = state_dir
            def state_path(self, task_id):
                if "/" in task_id or ".." in task_id:
                    raise ValueError("traversal rejected")
                p = (self.state_dir / f"{task_id}.json").resolve()
                if not p.is_relative_to(self.state_dir.resolve()):
                    raise ValueError("escape rejected")
                return p

        # Test hostile traversal input: ../escaped
        ad_b = DevCase1StoreAdapter(kernel)
        ad_b.execute_subject({"state_dir": state_dir, "task_id": "../escaped", "store_class": StoreBefore})
        verdict_b = ad_b.run_verification().verdict

        ad_a = DevCase1StoreAdapter(kernel)
        ad_a.execute_subject({"state_dir": state_dir, "task_id": "../escaped", "store_class": StoreAfter})
        verdict_a = ad_a.run_verification().verdict

        outcome = "VIOLATION_BEFORE_ONLY" if verdict_b == InvariantVerdict.VIOLATION and verdict_a == InvariantVerdict.PASS else "OTHER"
        results["development_results"].append({
            "case_id": "#1 nexus-rt-store-eeb147a",
            "family": "RV1_TRUSTED_ROOT_CONTAINMENT",
            "verdict_before": verdict_b.value,
            "verdict_after": verdict_a.value,
            "outcome": outcome,
            "claim": "DEVELOPMENT_ONLY",
        })

    # Case #2: nexus-new-wiki-09c9afc64 (Subprocess isolation)
    with tempfile.TemporaryDirectory() as td:
        repo_root = Path(td) / "repo"
        repo_root.mkdir()

        def runner_before(root, run_cmd):
            return run_cmd(["audit"], cwd=root)

        def runner_after(root, run_cmd):
            with tempfile.TemporaryDirectory() as temp_dir:
                return run_cmd(["audit"], cwd=Path(temp_dir))

        ad2_b = DevCase2WikiGateAdapter(kernel)
        ad2_b.execute_subject({"repo_root": repo_root, "runner_function": runner_before})
        v2_b = ad2_b.run_verification().verdict

        ad2_a = DevCase2WikiGateAdapter(kernel)
        ad2_a.execute_subject({"repo_root": repo_root, "runner_function": runner_after})
        v2_a = ad2_a.run_verification().verdict

        outcome2 = "VIOLATION_BEFORE_ONLY" if v2_b == InvariantVerdict.VIOLATION and v2_a == InvariantVerdict.PASS else "OTHER"
        results["development_results"].append({
            "case_id": "#2 nexus-new-wiki-09c9afc64",
            "family": "RV2_ISOLATED_EXECUTION_ROOT",
            "verdict_before": v2_b.value,
            "verdict_after": v2_a.value,
            "outcome": outcome2,
            "claim": "DEVELOPMENT_ONLY",
        })

    # Case #5: devspace-cutover-5d37965 (Validation-before-effect ordering)
    def cutover_before(validate_fn, effect_fn, args):
        # Before: executed effect before checking confirmCutoverId === cutoverId
        effect_fn()
        validate_fn(args.get("confirmCutoverId") == args.get("cutoverId"))

    def cutover_after(validate_fn, effect_fn, args):
        # After: validates first; if invalid, aborts with zero effect
        is_valid = args.get("confirmCutoverId") == args.get("cutoverId")
        validate_fn(is_valid)
        if is_valid:
            effect_fn()

    hostile_args = {"cutoverId": "cut-1", "confirmCutoverId": "cut-WRONG"}

    ad5_b = DevCase5CutoverAdapter(kernel)
    ad5_b.execute_subject({"cutover_function": cutover_before, "args": hostile_args, "operation_id": "op-cutover-5"})
    v5_b = ad5_b.run_verification().verdict

    ad5_a = DevCase5CutoverAdapter(kernel)
    ad5_a.execute_subject({"cutover_function": cutover_after, "args": hostile_args, "operation_id": "op-cutover-5"})
    v5_a = ad5_a.run_verification().verdict

    outcome5 = "VIOLATION_BEFORE_ONLY" if v5_b == InvariantVerdict.VIOLATION and v5_a == InvariantVerdict.PASS else "OTHER"
    results["development_results"].append({
        "case_id": "#5 devspace-cutover-5d37965",
        "family": "RV3_VALIDATION_PRECEDES_PROTECTED_EFFECT",
        "verdict_before": v5_b.value,
        "verdict_after": v5_a.value,
        "outcome": outcome5,
        "claim": "DEVELOPMENT_ONLY",
    })

    # =========================================================================
    # 2. UNSEEN HOLDOUT EVALUATIONS
    # =========================================================================

    # Unseen 1: holdout-rv1-taskservice-6f0a50c (symlinked runner temp parent)
    with tempfile.TemporaryDirectory() as td:
        trusted_base = Path(td) / "trusted_runner"
        trusted_base.mkdir()
        outside_dir = Path(td) / "outside"
        outside_dir.mkdir()
        symlink_parent = trusted_base / "symlink_escape"
        os.symlink(outside_dir, symlink_parent)

        def runner_fn_before(base):
            # Pre-fix: resolved path through symlink escaping base
            return symlink_parent / "job_run.log"

        def runner_fn_after(base):
            # Post-fix: validates no symlink parent escaping base
            target = symlink_parent / "job_run.log"
            if not target.resolve().is_relative_to(base.resolve()):
                raise ValueError("Symlink escape rejected")
            return target

        ad_u1_b = HoldoutRV1TaskServiceAdapter(kernel)
        ad_u1_b.execute_subject({"base_dir": trusted_base, "runner_function": runner_fn_before})
        u1_vb = ad_u1_b.run_verification().verdict

        ad_u1_a = HoldoutRV1TaskServiceAdapter(kernel)
        ad_u1_a.execute_subject({"base_dir": trusted_base, "runner_function": runner_fn_after})
        u1_va = ad_u1_a.run_verification().verdict

        out_u1 = "VIOLATION_BEFORE_ONLY" if u1_vb == InvariantVerdict.VIOLATION and u1_va == InvariantVerdict.PASS else "OTHER"
        results["unseen_holdout_results"].append({
            "case_id": "holdout-rv1-taskservice-6f0a50c",
            "family": "RV1_TRUSTED_ROOT_CONTAINMENT",
            "verdict_before": u1_vb.value,
            "verdict_after": u1_va.value,
            "outcome": out_u1,
        })

    # Unseen 2: holdout-rv1-projection-c8e7c50 (symlinked projection roots)
    with tempfile.TemporaryDirectory() as td:
        root_dir = Path(td) / "project_root"
        root_dir.mkdir()
        outside_store = Path(td) / "outside_store"
        outside_store.mkdir()
        symlinked_target = root_dir / "link_out"
        os.symlink(outside_store, symlinked_target)

        def proj_before(root, path):
            return symlinked_target / "receipt.json"

        def proj_after(root, path):
            p = (symlinked_target / "receipt.json").resolve()
            if not p.is_relative_to(root.resolve()):
                raise ValueError("projection root outside project rejected")
            return p

        ad_u2_b = HoldoutRV1ProjectionAdapter(kernel)
        ad_u2_b.execute_subject({"trusted_root": root_dir, "target_path": "receipt.json", "resolver_function": proj_before})
        u2_vb = ad_u2_b.run_verification().verdict

        ad_u2_a = HoldoutRV1ProjectionAdapter(kernel)
        ad_u2_a.execute_subject({"trusted_root": root_dir, "target_path": "receipt.json", "resolver_function": proj_after})
        u2_va = ad_u2_a.run_verification().verdict

        out_u2 = "VIOLATION_BEFORE_ONLY" if u2_vb == InvariantVerdict.VIOLATION and u2_va == InvariantVerdict.PASS else "OTHER"
        results["unseen_holdout_results"].append({
            "case_id": "holdout-rv1-projection-c8e7c50",
            "family": "RV1_TRUSTED_ROOT_CONTAINMENT",
            "verdict_before": u2_vb.value,
            "verdict_after": u2_va.value,
            "outcome": out_u2,
        })

    # Unseen 3: holdout-rv2-sandbox-c35be47 (sandbox execution isolation)
    with tempfile.TemporaryDirectory() as td:
        repo_root = Path(td) / "authoritative_repo"
        repo_root.mkdir()

        def sandbox_before(root, hook):
            # Pre-fix: in-place execution when sandbox copy fails
            return hook(cwd=root, mutating=True, ephemeral=False)

        def sandbox_after(root, hook):
            # Post-fix: guaranteed isolated temp copy
            with tempfile.TemporaryDirectory() as temp_sandbox:
                return hook(cwd=Path(temp_sandbox), mutating=True, ephemeral=True)

        ad_u3_b = HoldoutRV2SandboxAdapter(kernel)
        ad_u3_b.execute_subject({"repo_root": repo_root, "sandbox_function": sandbox_before})
        u3_vb = ad_u3_b.run_verification().verdict

        ad_u3_a = HoldoutRV2SandboxAdapter(kernel)
        ad_u3_a.execute_subject({"repo_root": repo_root, "sandbox_function": sandbox_after})
        u3_va = ad_u3_a.run_verification().verdict

        out_u3 = "VIOLATION_BEFORE_ONLY" if u3_vb == InvariantVerdict.VIOLATION and u3_va == InvariantVerdict.PASS else "OTHER"
        results["unseen_holdout_results"].append({
            "case_id": "holdout-rv2-sandbox-c35be47",
            "family": "RV2_ISOLATED_EXECUTION_ROOT",
            "verdict_before": u3_vb.value,
            "verdict_after": u3_va.value,
            "outcome": out_u3,
        })

    # Unseen 4: holdout-rv3-shutdown-22a5ebf (session release during shutdown)
    def release_before(validate_fn, effect_fn, params):
        # Pre-fix: released session without checking entry.closing
        effect_fn()
        validate_fn(params.get("closing") is False)

    def release_after(validate_fn, effect_fn, params):
        # Post-fix: validate first; if closing, do not release
        can_release = not (params.get("closing") and params.get("reason") == "idle_timeout")
        validate_fn(can_release)
        if can_release:
            effect_fn()

    hostile_shutdown_params = {"closing": True, "reason": "idle_timeout"}

    ad_u4_b = HoldoutRV3ShutdownAdapter(kernel)
    ad_u4_b.execute_subject({"release_function": release_before, "params": hostile_shutdown_params, "op_id": "release-shutdown"})
    u4_vb = ad_u4_b.run_verification().verdict

    ad_u4_a = HoldoutRV3ShutdownAdapter(kernel)
    ad_u4_a.execute_subject({"release_function": release_after, "params": hostile_shutdown_params, "op_id": "release-shutdown"})
    u4_va = ad_u4_a.run_verification().verdict

    out_u4 = "VIOLATION_BEFORE_ONLY" if u4_vb == InvariantVerdict.VIOLATION and u4_va == InvariantVerdict.PASS else "OTHER"
    results["unseen_holdout_results"].append({
        "case_id": "holdout-rv3-shutdown-22a5ebf",
        "family": "RV3_VALIDATION_PRECEDES_PROTECTED_EFFECT",
        "verdict_before": u4_vb.value,
        "verdict_after": u4_va.value,
        "outcome": out_u4,
    })

    # =========================================================================
    # 3. BENIGN CONTROLS (LOW_RISK)
    # =========================================================================
    with tempfile.TemporaryDirectory() as td:
        safe_root = Path(td) / "safe_root"
        safe_root.mkdir()
        safe_file = safe_root / "subdir" / "data.json"
        safe_file.parent.mkdir()
        safe_file.touch()

        # Benign 1: Legitimate subpath write
        res_b1 = kernel.evaluate_trace([
            RuntimeEvent(event_type=EventType.FS_EFFECT, target_path=str(safe_file), trusted_root=str(safe_root))
        ])
        results["benign_control_results"].append({
            "control_id": "benign-rv1-nested-valid",
            "verdict": res_b1.verdict.value,
            "status": "PASS_THROUGH" if res_b1.verdict == InvariantVerdict.PASS else "FALSE_POSITIVE"
        })

        # Benign 2: Mutating in dedicated tempdir
        temp_dir = Path(td) / "ephemeral_run"
        temp_dir.mkdir()
        res_b2 = kernel.evaluate_trace([
            RuntimeEvent(event_type=EventType.PROC_EXEC, exec_cwd=str(temp_dir), authoritative_root=str(safe_root), is_mutating=True, is_ephemeral=True)
        ])
        results["benign_control_results"].append({
            "control_id": "benign-rv2-temp-isolated",
            "verdict": res_b2.verdict.value,
            "status": "PASS_THROUGH" if res_b2.verdict == InvariantVerdict.PASS else "FALSE_POSITIVE"
        })

        # Benign 3: Read-only in authoritative root
        res_b3 = kernel.evaluate_trace([
            RuntimeEvent(event_type=EventType.PROC_EXEC, exec_cwd=str(safe_root), authoritative_root=str(safe_root), is_mutating=False, is_ephemeral=False)
        ])
        results["benign_control_results"].append({
            "control_id": "benign-rv2-readonly-root",
            "verdict": res_b3.verdict.value,
            "status": "PASS_THROUGH" if res_b3.verdict == InvariantVerdict.PASS else "FALSE_POSITIVE"
        })

        # Benign 4: Proper validation pass before protected effect
        res_b4 = kernel.evaluate_trace([
            RuntimeEvent(event_type=EventType.VALIDATION_PASS, operation_id="benign-op"),
            RuntimeEvent(event_type=EventType.PROTECTED_EFFECT, operation_id="benign-op"),
        ])
        results["benign_control_results"].append({
            "control_id": "benign-rv3-precondition-pass",
            "verdict": res_b4.verdict.value,
            "status": "PASS_THROUGH" if res_b4.verdict == InvariantVerdict.PASS else "FALSE_POSITIVE"
        })

    # =========================================================================
    # 4. METAMORPHIC & FALSIFICATION TESTS
    # =========================================================================

    # Metamorphic 1 (RV1): Renaming target path retains invariant
    with tempfile.TemporaryDirectory() as td:
        m_root = Path(td) / "m_root"
        m_root.mkdir()
        safe_1 = m_root / "alpha.json"
        safe_2 = m_root / "beta_renamed.json"
        safe_1.touch()
        safe_2.touch()
        r1 = kernel.evaluate_trace([RuntimeEvent(event_type=EventType.FS_EFFECT, target_path=str(safe_1), trusted_root=str(m_root))])
        r2 = kernel.evaluate_trace([RuntimeEvent(event_type=EventType.FS_EFFECT, target_path=str(safe_2), trusted_root=str(m_root))])
        results["metamorphic_results"].append({
            "name": "RV1_Metamorphic_Rename_Path_Invariance",
            "pass": r1.verdict == r2.verdict == InvariantVerdict.PASS
        })

    # Metamorphic 2 (RV3): Event permutation (Inverting order turns PASS into VIOLATION)
    t_pass = [
        RuntimeEvent(event_type=EventType.VALIDATION_PASS, operation_id="meta-3"),
        RuntimeEvent(event_type=EventType.PROTECTED_EFFECT, operation_id="meta-3"),
    ]
    t_inverted = [
        RuntimeEvent(event_type=EventType.PROTECTED_EFFECT, operation_id="meta-3"),
        RuntimeEvent(event_type=EventType.VALIDATION_PASS, operation_id="meta-3"),
    ]
    rm_pass = kernel.evaluate_trace(t_pass)
    rm_inv = kernel.evaluate_trace(t_inverted)
    results["metamorphic_results"].append({
        "name": "RV3_Metamorphic_Permutation_Inversion",
        "pass": rm_pass.verdict == InvariantVerdict.PASS and rm_inv.verdict == InvariantVerdict.VIOLATION
    })

    return results


if __name__ == "__main__":
    res = run_full_evaluation()
    print(json.dumps(res, indent=2))
