"""
Subject Materialization and Execution Loader (DSG-E3 Physical Replay)

Responsible for:
1. Extracting authentic source bytes from git objects at exact commits.
2. Materializing files into ephemeral directories in /private/tmp.
3. Importing and dynamically binding callables for execution.
4. Capturing physical execution witnesses (materialized file SHA, module path).
"""
from __future__ import annotations

import hashlib
import importlib.util
import os
import subprocess
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Dict, Optional, Tuple


@dataclass
class MaterializedSubject:
    case_id: str
    version: str  # BEFORE or AFTER
    commit_sha: str
    file_path: str
    materialized_path: Path
    file_sha256: str
    temp_dir: str

    def cleanup(self) -> None:
        if os.path.exists(self.temp_dir):
            import shutil
            shutil.rmtree(self.temp_dir, ignore_errors=True)


class SubjectLoader:
    """Safely materializes historical code directly from Git."""

    @staticmethod
    def materialize_git_file(
        repo_path: str,
        commit_sha: str,
        rel_path: str,
        case_id: str,
        version: str,
    ) -> MaterializedSubject:
        raw_bytes = subprocess.check_output(
            ["git", "-C", repo_path, "cat-file", "-p", f"{commit_sha}:{rel_path}"]
        )
        file_sha256 = hashlib.sha256(raw_bytes).hexdigest()

        td = tempfile.mkdtemp(prefix=f"dsg_e3_subj_{case_id}_{version}_")
        dest = Path(td) / Path(rel_path).name
        dest.write_bytes(raw_bytes)

        return MaterializedSubject(
            case_id=case_id,
            version=version,
            commit_sha=commit_sha,
            file_path=rel_path,
            materialized_path=dest,
            file_sha256=file_sha256,
            temp_dir=td,
        )

    @staticmethod
    def load_python_module(subject: MaterializedSubject, module_name: str) -> Any:
        spec = importlib.util.spec_from_file_location(module_name, subject.materialized_path)
        if spec is None or spec.loader is None:
            raise ImportError(f"Cannot load spec for {subject.materialized_path}")
        mod = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = mod
        spec.loader.exec_module(mod)
        return mod
