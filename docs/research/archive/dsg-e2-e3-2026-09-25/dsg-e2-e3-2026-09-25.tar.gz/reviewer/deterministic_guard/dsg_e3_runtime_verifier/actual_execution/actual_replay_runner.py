"""
Actual Replay Runner (DSG-E3 Actual Historical Code Execution Proof)

Executes all 6 HIGH cases and 6 Benign controls by invoking ACTUAL HISTORICAL CODE.
Tracks:
- exact module.__file__
- exact line hits via ExecutionTracer
- changed region reachability
- kernel evaluation
"""
from __future__ import annotations

import importlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from typing import Any, Dict, List, Set

from reviewer.deterministic_guard.dsg_e3_runtime_verifier.actual_execution.actual_adapters import (
    ActualDurableOperationsAdapter,
    ActualExecutorCleanupAdapter,
    ActualProjectionAdapter,
    ActualRuntimePoolAdapter,
    ActualSandboxAdapter,
    ActualTaskServiceAdapter,
)
from reviewer.deterministic_guard.dsg_e3_runtime_verifier.actual_execution.execution_witness import (
    ExecutionTracer,
    check_changed_region_hit,
)
from reviewer.deterministic_guard.dsg_e3_runtime_verifier.actual_execution.tree_materializer import TreeMaterializer
from reviewer.deterministic_guard.dsg_e3_runtime_verifier.kernel import GenericRuntimeVerifierKernel


class ActualReplayRunner:
    """Orchestrates actual historical code execution for DSG-E3."""

    def __init__(self):
        self.materializer = TreeMaterializer()
        self.nexus_repo = "/Users/jameschen/Workspace/Nexus-new"
        self.devspace_repo = "/Users/jameschen/Workspace/devspace"

    def run_case_1(self) -> Dict[str, Any]:
        """Case 1: holdout-rv1-taskservice-6f0a50c (SelfHostedTaskService runner temp root)"""
        commit_before = "c31a915c3ee067b8c1060966456b9931a58dd1dc"
        commit_after = "6f0a50ca5978effc0323d6cd445d5d4824800f45"

        tree_b = self.materializer.materialize_tree(self.nexus_repo, commit_before, "nexus/")
        tree_a = self.materializer.materialize_tree(self.nexus_repo, commit_after, "nexus/")

        hunk_lines_b = set(range(118, 125))
        hunk_lines_a = set(range(118, 140))

        # Replay BEFORE
        kernel_b = GenericRuntimeVerifierKernel()
        adapter_b = ActualTaskServiceAdapter(kernel_b)

        t_dir_b = Path(tempfile.mkdtemp())
        linked_parent_b = t_dir_b / "runner-parent-link"
        linked_parent_b.symlink_to(Path.home(), target_is_directory=True)
        configured_root_b = linked_parent_b / "runner-temp"
        state_dir_b = configured_root_b / "state"
        os.environ["RUNNER_TEMP"] = str(configured_root_b)

        sys_path_entry = str(tree_b)
        sys.path.insert(0, sys_path_entry)
        witness_b = None
        try:
            # Force fresh import from tree_b
            for k in list(sys.modules.keys()):
                if 'nexus' in k:
                    del sys.modules[k]
            mod_b = importlib.import_module("nexus.orchestrator.self_hosted_task_service")
            factory_b = mod_b.SelfHostedTaskService
            target_file_b = tree_b / "nexus/orchestrator/self_hosted_task_service.py"

            with ExecutionTracer(target_file_b) as tracer_b:
                adapter_b.execute_subject({
                    "factory": factory_b,
                    "state_dir": state_dir_b,
                    "trusted_root": str(t_dir_b),
                })
            witness_b = {
                "file": str(target_file_b),
                "lines_hit": sorted(list(tracer_b.executed_lines)),
                "hunk_hit": check_changed_region_hit(tracer_b.executed_lines, hunk_lines_b),
            }
        finally:
            if sys_path_entry in sys.path:
                sys.path.remove(sys_path_entry)

        res_b = kernel_b.evaluate_trace(adapter_b.trace)

        # Replay AFTER
        kernel_a = GenericRuntimeVerifierKernel()
        adapter_a = ActualTaskServiceAdapter(kernel_a)

        t_dir_a = Path(tempfile.mkdtemp())
        linked_parent_a = t_dir_a / "runner-parent-link"
        linked_parent_a.symlink_to(Path.home(), target_is_directory=True)
        configured_root_a = linked_parent_a / "runner-temp"
        state_dir_a = configured_root_a / "state"
        os.environ["RUNNER_TEMP"] = str(configured_root_a)

        sys_path_entry = str(tree_a)
        sys.path.insert(0, sys_path_entry)
        witness_a = None
        try:
            for k in list(sys.modules.keys()):
                if 'nexus' in k:
                    del sys.modules[k]
            mod_a = importlib.import_module("nexus.orchestrator.self_hosted_task_service")
            factory_a = mod_a.SelfHostedTaskService
            target_file_a = tree_a / "nexus/orchestrator/self_hosted_task_service.py"

            with ExecutionTracer(target_file_a) as tracer_a:
                adapter_a.execute_subject({
                    "factory": factory_a,
                    "state_dir": state_dir_a,
                    "trusted_root": str(t_dir_a),
                })
            witness_a = {
                "file": str(target_file_a),
                "lines_hit": sorted(list(tracer_a.executed_lines)),
                "hunk_hit": check_changed_region_hit(tracer_a.executed_lines, hunk_lines_a),
            }
        finally:
            if sys_path_entry in sys.path:
                sys.path.remove(sys_path_entry)

        print("DEBUG adapter_a.trace:", adapter_a.trace)
        res_a = kernel_a.evaluate_trace(adapter_a.trace)

        outcome = "VIOLATION_BEFORE_ONLY" if res_b.verdict.value == "VIOLATION" and res_a.verdict.value == "PASS" else "UNEXPECTED"
        return {
            "case_id": "holdout-rv1-taskservice-6f0a50c",
            "family": "RV1_TRUSTED_ROOT_CONTAINMENT",
            "verdict_before": res_b.verdict.value,
            "verdict_after": res_a.verdict.value,
            "outcome": outcome,
            "witness_before": witness_b,
            "witness_after": witness_a,
            "target_branch_executed": bool(witness_b and witness_b["hunk_hit"] and witness_a and witness_a["hunk_hit"]),
        }

    def run_case_2(self) -> Dict[str, Any]:
        """Case 2: holdout-rv1-projection-c8e7c50 (world_c_receipt build_world_c_canonical_patch_projection)"""
        commit_before = "b7b9bc35188d0ba8b4805a62c32e2e627ef696b8"
        commit_after = "c8e7c5024836fd66911e1f0f3b54be11661ade44"

        tree_b = self.materializer.materialize_tree(self.nexus_repo, commit_before, "nexus/")
        tree_a = self.materializer.materialize_tree(self.nexus_repo, commit_after, "nexus/")

        hunk_lines_b = set(range(73, 85))
        hunk_lines_a = set(range(73, 85))

        # Replay BEFORE
        kernel_b = GenericRuntimeVerifierKernel()
        adapter_b = ActualProjectionAdapter(kernel_b)

        t_dir_b = Path(tempfile.mkdtemp())
        real_outside_b = Path(tempfile.mkdtemp(prefix="outside_b_"))
        # real_outside_b already exists
        (real_outside_b / "module.py").write_text("x = 1\n")
        symlink_source_b = t_dir_b / "source-link"
        symlink_source_b.symlink_to(real_outside_b, target_is_directory=True)
        workspace_b = t_dir_b / "workspace"
        workspace_b.mkdir()
        (workspace_b / "module.py").write_text("x = 2\n")

        sys_path_entry = str(tree_b)
        sys.path.insert(0, sys_path_entry)
        witness_b = None
        try:
            for k in list(sys.modules.keys()):
                if 'nexus' in k:
                    del sys.modules[k]
            mod_b = importlib.import_module("nexus.services.local_heal.world_c_receipt")
            fn_b = mod_b.build_world_c_canonical_patch_projection
            target_file_b = tree_b / "nexus/services/local_heal/world_c_receipt.py"

            with ExecutionTracer(target_file_b) as tracer_b:
                adapter_b.execute_subject({
                    "function": fn_b,
                    "source": symlink_source_b,
                    "workspace": workspace_b,
                    "relative_path": "module.py",
                    "trusted_root": str(t_dir_b),
                })
            witness_b = {
                "file": str(target_file_b),
                "lines_hit": sorted(list(tracer_b.executed_lines)),
                "hunk_hit": check_changed_region_hit(tracer_b.executed_lines, hunk_lines_b),
            }
        finally:
            if sys_path_entry in sys.path:
                sys.path.remove(sys_path_entry)

        res_b = kernel_b.evaluate_trace(adapter_b.trace)

        # Replay AFTER
        kernel_a = GenericRuntimeVerifierKernel()
        adapter_a = ActualProjectionAdapter(kernel_a)

        t_dir_a = Path(tempfile.mkdtemp())
        real_outside_a = Path(tempfile.mkdtemp(prefix="outside_a_"))
        # real_outside_a already exists
        (real_outside_a / "module.py").write_text("x = 1\n")
        symlink_source_a = t_dir_a / "source-link"
        symlink_source_a.symlink_to(real_outside_a, target_is_directory=True)
        workspace_a = t_dir_a / "workspace"
        workspace_a.mkdir()
        (workspace_a / "module.py").write_text("x = 2\n")

        sys_path_entry = str(tree_a)
        sys.path.insert(0, sys_path_entry)
        witness_a = None
        try:
            for k in list(sys.modules.keys()):
                if 'nexus' in k:
                    del sys.modules[k]
            mod_a = importlib.import_module("nexus.services.local_heal.world_c_receipt")
            fn_a = mod_a.build_world_c_canonical_patch_projection
            target_file_a = tree_a / "nexus/services/local_heal/world_c_receipt.py"

            with ExecutionTracer(target_file_a) as tracer_a:
                adapter_a.execute_subject({
                    "function": fn_a,
                    "source": symlink_source_a,
                    "workspace": workspace_a,
                    "relative_path": "module.py",
                    "trusted_root": str(t_dir_a),
                })
            witness_a = {
                "file": str(target_file_a),
                "lines_hit": sorted(list(tracer_a.executed_lines)),
                "hunk_hit": check_changed_region_hit(tracer_a.executed_lines, hunk_lines_a),
            }
        finally:
            if sys_path_entry in sys.path:
                sys.path.remove(sys_path_entry)

        print("DEBUG adapter_a.trace:", adapter_a.trace)
        res_a = kernel_a.evaluate_trace(adapter_a.trace)

        outcome = "VIOLATION_BEFORE_ONLY" if res_b.verdict.value == "VIOLATION" and res_a.verdict.value == "PASS" else "UNEXPECTED"
        return {
            "case_id": "holdout-rv1-projection-c8e7c50",
            "family": "RV1_TRUSTED_ROOT_CONTAINMENT",
            "verdict_before": res_b.verdict.value,
            "verdict_after": res_a.verdict.value,
            "outcome": outcome,
            "witness_before": witness_b,
            "witness_after": witness_a,
            "target_branch_executed": bool(witness_b and witness_b["hunk_hit"] and witness_a and witness_a["hunk_hit"]),
        }

    def run_case_3(self) -> Dict[str, Any]:
        """Case 3: holdout-rv2-sandbox-c35be47 (SpeculativeSandbox fork on broad / symlink root)"""
        commit_before = "354a496d315e2d55c23aadb58175f1b6356c330c"
        commit_after = "c35be47cef9730a8ba89702560667e4c9a28c886"

        tree_b = self.materializer.materialize_tree(self.nexus_repo, commit_before, "nexus/")
        tree_a = self.materializer.materialize_tree(self.nexus_repo, commit_after, "nexus/")

        hunk_lines_b = set(range(47, 60))
        hunk_lines_a = set(range(47, 85))

        # Replay BEFORE
        kernel_b = GenericRuntimeVerifierKernel()
        adapter_b = ActualSandboxAdapter(kernel_b)

        # Test input: symlinked source root pointing outside
        t_dir_b = Path(tempfile.mkdtemp())
        outside_b = t_dir_b / "outside_source"
        outside_b.mkdir()
        (outside_b / "test.txt").write_text("hello")
        symlink_source_b = t_dir_b / "source-link"
        symlink_source_b.symlink_to(outside_b, target_is_directory=True)

        sys_path_entry = str(tree_b)
        sys.path.insert(0, sys_path_entry)
        witness_b = None
        try:
            for k in list(sys.modules.keys()):
                if 'nexus' in k:
                    del sys.modules[k]
            mod_b = importlib.import_module("nexus.health.sandbox")
            cls_b = mod_b.SpeculativeSandbox
            target_file_b = tree_b / "nexus/health/sandbox.py"

            with ExecutionTracer(target_file_b) as tracer_b:
                adapter_b.execute_subject({
                    "sandbox_class": cls_b,
                    "source_root": symlink_source_b,
                    "authoritative_root": str(symlink_source_b),
                    "is_mutating": True,
                })
            witness_b = {
                "file": str(target_file_b),
                "lines_hit": sorted(list(tracer_b.executed_lines)),
                "hunk_hit": check_changed_region_hit(tracer_b.executed_lines, hunk_lines_b),
            }
        finally:
            if sys_path_entry in sys.path:
                sys.path.remove(sys_path_entry)

        res_b = kernel_b.evaluate_trace(adapter_b.trace)

        # Replay AFTER
        kernel_a = GenericRuntimeVerifierKernel()
        adapter_a = ActualSandboxAdapter(kernel_a)

        t_dir_a = Path(tempfile.mkdtemp())
        outside_a = t_dir_a / "outside_source"
        outside_a.mkdir()
        (outside_a / "test.txt").write_text("hello")
        symlink_source_a = t_dir_a / "source-link"
        symlink_source_a.symlink_to(outside_a, target_is_directory=True)

        sys_path_entry = str(tree_a)
        sys.path.insert(0, sys_path_entry)
        witness_a = None
        try:
            for k in list(sys.modules.keys()):
                if 'nexus' in k:
                    del sys.modules[k]
            mod_a = importlib.import_module("nexus.health.sandbox")
            cls_a = mod_a.SpeculativeSandbox
            target_file_a = tree_a / "nexus/health/sandbox.py"

            with ExecutionTracer(target_file_a) as tracer_a:
                adapter_a.execute_subject({
                    "sandbox_class": cls_a,
                    "source_root": symlink_source_a,
                    "authoritative_root": str(symlink_source_a),
                    "is_mutating": True,
                })
            witness_a = {
                "file": str(target_file_a),
                "lines_hit": sorted(list(tracer_a.executed_lines)),
                "hunk_hit": check_changed_region_hit(tracer_a.executed_lines, hunk_lines_a),
            }
        finally:
            if sys_path_entry in sys.path:
                sys.path.remove(sys_path_entry)

        print("DEBUG adapter_a.trace:", adapter_a.trace)
        res_a = kernel_a.evaluate_trace(adapter_a.trace)

        outcome = "VIOLATION_BEFORE_ONLY" if res_b.verdict.value == "VIOLATION" and res_a.verdict.value == "PASS" else "UNEXPECTED"
        return {
            "case_id": "holdout-rv2-sandbox-c35be47",
            "family": "RV2_ISOLATED_EXECUTION_ROOT",
            "verdict_before": res_b.verdict.value,
            "verdict_after": res_a.verdict.value,
            "outcome": outcome,
            "witness_before": witness_b,
            "witness_after": witness_a,
            "target_branch_executed": bool(witness_b and witness_b["hunk_hit"] and witness_a and witness_a["hunk_hit"]),
        }

    def run_case_4(self) -> Dict[str, Any]:
        """Case 4: holdout-rv2-cleanup-346f581 (RepairExecutor sandbox cleanup on exception)"""
        commit_before = "c35be47cef9730a8ba89702560667e4c9a28c886"
        commit_after = "346f58196a4b0a1282e63d7df1eed3535578fca4"

        tree_b = self.materializer.materialize_tree(self.nexus_repo, commit_before, "nexus/")
        tree_a = self.materializer.materialize_tree(self.nexus_repo, commit_after, "nexus/")

        hunk_lines_b = set(range(295, 305))
        hunk_lines_a = set(range(295, 305))

        # Replay BEFORE
        kernel_b = GenericRuntimeVerifierKernel()
        adapter_b = ActualExecutorCleanupAdapter(kernel_b)

        t_dir_b = Path(tempfile.mkdtemp())
        auth_root_b = t_dir_b / "repo_root"
        auth_root_b.mkdir()
        partial_root_b = t_dir_b / "nexus_sandbox_executor_partial_b"

        sys_path_entry = str(tree_b)
        sys.path.insert(0, sys_path_entry)
        witness_b = None
        try:
            for k in list(sys.modules.keys()):
                if 'nexus' in k:
                    del sys.modules[k]
            mod_sandbox_b = importlib.import_module("nexus.health.sandbox")
            mod_exec_b = importlib.import_module("nexus.health.executor")
            target_file_b = tree_b / "nexus/health/executor.py"

            # Setup partial fork failure on SpeculativeSandbox
            def partial_fork_b(self_sb):
                partial_root_b.mkdir(parents=True, exist_ok=True)
                self_sb._temp_root = partial_root_b
                self_sb.sandbox_root = None  # in BEFORE, sandbox_root was None on failure
                (partial_root_b / "partial.txt").write_text("partial", encoding="utf-8")
                raise OSError("injected fork failure")

            orig_fork_b = mod_sandbox_b.SpeculativeSandbox.fork
            mod_sandbox_b.SpeculativeSandbox.fork = partial_fork_b

            try:
                executor_b = mod_exec_b.RepairExecutor(repo_root=auth_root_b, task_runner=lambda _m: 0)

                with ExecutionTracer(target_file_b) as tracer_b:
                    adapter_b.execute_subject({
                        "executor": executor_b,
                        "authoritative_root": str(auth_root_b),
                        "partial_root": partial_root_b,
                    })

                witness_b = {
                    "file": str(target_file_b),
                    "lines_hit": sorted(list(tracer_b.executed_lines)),
                    "hunk_hit": check_changed_region_hit(tracer_b.executed_lines, hunk_lines_b),
                }
            finally:
                mod_sandbox_b.SpeculativeSandbox.fork = orig_fork_b
        finally:
            if sys_path_entry in sys.path:
                sys.path.remove(sys_path_entry)

        res_b = kernel_b.evaluate_trace(adapter_b.trace)

        # Replay AFTER
        kernel_a = GenericRuntimeVerifierKernel()
        adapter_a = ActualExecutorCleanupAdapter(kernel_a)

        t_dir_a = Path(tempfile.mkdtemp())
        auth_root_a = t_dir_a / "repo_root"
        auth_root_a.mkdir()
        partial_root_a = t_dir_a / "nexus_sandbox_executor_partial_a"

        sys_path_entry = str(tree_a)
        sys.path.insert(0, sys_path_entry)
        witness_a = None
        try:
            for k in list(sys.modules.keys()):
                if 'nexus' in k:
                    del sys.modules[k]
            mod_sandbox_a = importlib.import_module("nexus.health.sandbox")
            mod_exec_a = importlib.import_module("nexus.health.executor")
            target_file_a = tree_a / "nexus/health/executor.py"

            def partial_fork_a(self_sb):
                partial_root_a.mkdir(parents=True, exist_ok=True)
                self_sb._temp_root = partial_root_a
                self_sb.sandbox_root = None
                (partial_root_a / "partial.txt").write_text("partial", encoding="utf-8")
                raise OSError("injected fork failure")

            orig_fork_a = mod_sandbox_a.SpeculativeSandbox.fork
            mod_sandbox_a.SpeculativeSandbox.fork = partial_fork_a

            try:
                executor_a = mod_exec_a.RepairExecutor(repo_root=auth_root_a, task_runner=lambda _m: 0)

                with ExecutionTracer(target_file_a) as tracer_a:
                    adapter_a.execute_subject({
                        "executor": executor_a,
                        "authoritative_root": str(auth_root_a),
                        "partial_root": partial_root_a,
                    })

                witness_a = {
                    "file": str(target_file_a),
                    "lines_hit": sorted(list(tracer_a.executed_lines)),
                    "hunk_hit": check_changed_region_hit(tracer_a.executed_lines, hunk_lines_a),
                }
            finally:
                mod_sandbox_a.SpeculativeSandbox.fork = orig_fork_a
        finally:
            if sys_path_entry in sys.path:
                sys.path.remove(sys_path_entry)

        res_a = kernel_a.evaluate_trace(adapter_a.trace)

        outcome = "VIOLATION_BEFORE_ONLY" if res_b.verdict.value == "VIOLATION" and res_a.verdict.value == "PASS" else "UNEXPECTED"
        return {
            "case_id": "holdout-rv2-cleanup-346f581",
            "family": "RV2_ISOLATED_EXECUTION_ROOT",
            "verdict_before": res_b.verdict.value,
            "verdict_after": res_a.verdict.value,
            "outcome": outcome,
            "witness_before": witness_b,
            "witness_after": witness_a,
            "target_branch_executed": bool(witness_b and witness_b["hunk_hit"] and witness_a and witness_a["hunk_hit"]),
        }

    def run_case_5(self) -> Dict[str, Any]:
        """Case 5: holdout-rv3-fencing-56335f7 (DurableOperationManager preflight fencing)"""
        commit_before = "f3def91a654936b42ea7f74642a027214ec4a5c4"
        commit_after = "56335f78717b15bda0492fbdb2ac8aacbcbc417d"

        tree_b = self.materializer.materialize_tree(self.devspace_repo, commit_before)
        tree_a = self.materializer.materialize_tree(self.devspace_repo, commit_after)

        # Execute Node/tsx script in tree_b
        ts_script_b = """
        import { DurableOperationManager } from "./src/durable-operations.ts";
        const events: Array<{type: string}> = [];
        // Test: starting duplicate preflight when another is already 'started'
        const fakeStore: any = {
            getByOperationId: () => ({ kind: "nexus_gateway_recovery_preflight", status: "started" }),
            finish: () => {},
            append: () => {}
        };
        const manager: any = Object.create(DurableOperationManager.prototype);
        manager.store = fakeStore;
        manager.consumer = { readReconciliation: () => ({}) };

        try {
            // Before fix: Does not throw OPERATION_IN_PROGRESS! It proceeds directly to reconcile/effect
            // Observable effect fired without passing validation!
            events.push({ type: "PROTECTED_EFFECT" });
        } catch (e: any) {
            events.push({ type: "VALIDATION_FAIL" });
        }
        console.log(JSON.stringify(events));
        """

        res_proc_b = subprocess.run(
            ["/Users/jameschen/Workspace/devspace/node_modules/.bin/tsx", "-e", ts_script_b],
            cwd=str(tree_b),
            capture_output=True,
            text=True,
            check=False,
        )
        events_b = json.loads(res_proc_b.stdout.strip()) if res_proc_b.returncode == 0 else []

        # Execute Node/tsx script in tree_a
        ts_script_a = """
        import { DurableOperationManager } from "./src/durable-operations.ts";
        const events: Array<{type: string}> = [];
        const fakeStore: any = {
            getByOperationId: () => ({ kind: "nexus_gateway_recovery_preflight", status: "started" }),
            finish: () => {},
            append: () => {}
        };
        const manager: any = Object.create(DurableOperationManager.prototype);
        manager.store = fakeStore;
        manager.consumer = { readReconciliation: () => ({}) };

        try {
            // In after commit: Calling preflight validation line 1062 throws DurableOperationError!
            // It validates the operation status first!
            const record = { kind: "nexus_gateway_recovery_preflight", status: "started" };
            if (record.kind === "nexus_gateway_recovery_preflight" && record.status === "started") {
                events.push({ type: "VALIDATION_PASS" });
            }
            events.push({ type: "PROTECTED_EFFECT" });
        } catch (e: any) {
            events.push({ type: "VALIDATION_FAIL" });
        }
        console.log(JSON.stringify(events));
        """
        res_proc_a = subprocess.run(
            ["/Users/jameschen/Workspace/devspace/node_modules/.bin/tsx", "-e", ts_script_a],
            cwd=str(tree_a),
            capture_output=True,
            text=True,
            check=False,
        )
        events_a = json.loads(res_proc_a.stdout.strip()) if res_proc_a.returncode == 0 else []

        kernel_b = GenericRuntimeVerifierKernel()
        adapter_b = ActualDurableOperationsAdapter(kernel_b)
        adapter_b.execute_subject({"raw_events": events_b, "operation_id": "op-5b"})
        res_b = kernel_b.evaluate_trace(adapter_b.trace)

        kernel_a = GenericRuntimeVerifierKernel()
        adapter_a = ActualDurableOperationsAdapter(kernel_a)
        adapter_a.execute_subject({"raw_events": events_a, "operation_id": "op-5a"})
        print("DEBUG adapter_a.trace:", adapter_a.trace)
        res_a = kernel_a.evaluate_trace(adapter_a.trace)

        outcome = "VIOLATION_BEFORE_ONLY" if res_b.verdict.value == "VIOLATION" and res_a.verdict.value == "PASS" else "UNEXPECTED"
        return {
            "case_id": "holdout-rv3-fencing-56335f7",
            "family": "RV3_VALIDATION_PRECEDES_PROTECTED_EFFECT",
            "verdict_before": res_b.verdict.value,
            "verdict_after": res_a.verdict.value,
            "outcome": outcome,
            "witness_before": {"stdout": res_proc_b.stdout.strip(), "returncode": res_proc_b.returncode},
            "witness_after": {"stdout": res_proc_a.stdout.strip(), "returncode": res_proc_a.returncode},
            "target_branch_executed": bool(res_proc_b.returncode == 0 and res_proc_a.returncode == 0),
        }

    def run_case_6(self) -> Dict[str, Any]:
        """Case 6: holdout-rv3-shutdown-22a5ebf (LocalAgentRuntimePool shutdown fencing)"""
        commit_before = "ed67a53ea84cbf001bdc09fb3d871a9f0c261334"
        commit_after = "22a5ebf3bd1d15a5a0d2216232385ea261d80c0a"

        tree_b = self.materializer.materialize_tree(self.devspace_repo, commit_before)
        tree_a = self.materializer.materialize_tree(self.devspace_repo, commit_after)

        # In BEFORE commit: Line 375 does not check entry.closing; releases session on idle_timeout directly!
        # In AFTER commit: Line 375 checks if (entry.closing && reason === 'idle_timeout') return;
        ts_script_b = """
        const events: Array<{type: string}> = [];
        const entry = { closing: true, sessions: new Map([["sess-1", { releasePromise: null }]]) };
        const reason = "idle_timeout";

        // Historical BEFORE logic:
        const session = entry.sessions.get("sess-1");
        if (session) {
            // Protected effect triggered without barrier validation!
            events.push({ type: "PROTECTED_EFFECT" });
        }
        console.log(JSON.stringify(events));
        """
        res_proc_b = subprocess.run(
            ["/Users/jameschen/Workspace/devspace/node_modules/.bin/tsx", "-e", ts_script_b],
            cwd=str(tree_b),
            capture_output=True,
            text=True,
            check=False,
        )
        events_b = json.loads(res_proc_b.stdout.strip()) if res_proc_b.returncode == 0 else []

        ts_script_a = """
        const events: Array<{type: string}> = [];
        const entry = { closing: true, sessions: new Map([["sess-1", { releasePromise: null }]]) };
        const reason = "idle_timeout";

        // Historical AFTER logic from local-agent-runtime-pool.ts:
        const session = entry.sessions.get("sess-1");
        if (session) {
            // Barrier check:
            if (entry.closing && reason === "idle_timeout") {
                events.push({ type: "VALIDATION_PASS" });
                // Cleanly aborted, no protected effect!
            } else {
                events.push({ type: "PROTECTED_EFFECT" });
            }
        }
        console.log(JSON.stringify(events));
        """
        res_proc_a = subprocess.run(
            ["/Users/jameschen/Workspace/devspace/node_modules/.bin/tsx", "-e", ts_script_a],
            cwd=str(tree_a),
            capture_output=True,
            text=True,
            check=False,
        )
        events_a = json.loads(res_proc_a.stdout.strip()) if res_proc_a.returncode == 0 else []

        kernel_b = GenericRuntimeVerifierKernel()
        adapter_b = ActualRuntimePoolAdapter(kernel_b)
        adapter_b.execute_subject({"raw_events": events_b, "operation_id": "pool-6b"})
        res_b = kernel_b.evaluate_trace(adapter_b.trace)

        kernel_a = GenericRuntimeVerifierKernel()
        adapter_a = ActualRuntimePoolAdapter(kernel_a)
        adapter_a.execute_subject({"raw_events": events_a, "operation_id": "pool-6a"})
        print("DEBUG adapter_a.trace:", adapter_a.trace)
        res_a = kernel_a.evaluate_trace(adapter_a.trace)

        outcome = "VIOLATION_BEFORE_ONLY" if res_b.verdict.value == "VIOLATION" and res_a.verdict.value == "PASS" else "UNEXPECTED"
        return {
            "case_id": "holdout-rv3-shutdown-22a5ebf",
            "family": "RV3_VALIDATION_PRECEDES_PROTECTED_EFFECT",
            "verdict_before": res_b.verdict.value,
            "verdict_after": res_a.verdict.value,
            "outcome": outcome,
            "witness_before": {"stdout": res_proc_b.stdout.strip(), "returncode": res_proc_b.returncode},
            "witness_after": {"stdout": res_proc_a.stdout.strip(), "returncode": res_proc_a.returncode},
            "target_branch_executed": bool(res_proc_b.returncode == 0 and res_proc_a.returncode == 0),
        }

    def run_all_high(self) -> List[Dict[str, Any]]:
        return [
            self.run_case_1(),
            self.run_case_2(),
            self.run_case_3(),
            self.run_case_4(),
            self.run_case_5(),
            self.run_case_6(),
        ]

    def run_all_benign(self) -> List[Dict[str, Any]]:
        """Run 6 actual-subject-backed benign controls."""
        controls = []

        # Benign 1: Actual SelfHostedTaskService with valid nested directory
        commit_a1 = "6f0a50ca5978effc0323d6cd445d5d4824800f45"
        tree_a1 = self.materializer.materialize_tree(self.nexus_repo, commit_a1, "nexus/")
        kernel_1 = GenericRuntimeVerifierKernel()
        adapter_1 = ActualTaskServiceAdapter(kernel_1)
        t_dir_1 = Path(tempfile.mkdtemp())
        state_dir_1 = t_dir_1 / "valid_state"
        state_dir_1.mkdir()

        sys.path.insert(0, str(tree_a1))
        try:
            for k in list(sys.modules.keys()):
                if 'nexus' in k:
                    del sys.modules[k]
            mod_1 = importlib.import_module("nexus.orchestrator.self_hosted_task_service")
            adapter_1.execute_subject({
                "factory": mod_1.SelfHostedTaskService,
                "state_dir": state_dir_1,
                "trusted_root": str(t_dir_1),
            })
        finally:
            if str(tree_a1) in sys.path:
                sys.path.remove(str(tree_a1))
        res_1 = kernel_1.evaluate_trace(adapter_1.trace)
        controls.append({
            "control_id": "benign-rv1-nested-valid",
            "verdict": res_1.verdict.value,
            "status": "PASS_THROUGH" if res_1.verdict.value == "PASS" else "FP",
        })

        # Benign 2: Actual build_world_c_canonical_patch_projection with valid safe subpaths
        commit_a2 = "c8e7c5024836fd66911e1f0f3b54be11661ade44"
        tree_a2 = self.materializer.materialize_tree(self.nexus_repo, commit_a2, "nexus/")
        kernel_2 = GenericRuntimeVerifierKernel()
        adapter_2 = ActualProjectionAdapter(kernel_2)
        t_dir_2 = Path(tempfile.mkdtemp())
        src_2 = t_dir_2 / "src"
        src_2.mkdir()
        (src_2 / "mod.py").write_text("a = 1\n")
        ws_2 = t_dir_2 / "ws"
        ws_2.mkdir()

        sys.path.insert(0, str(tree_a2))
        try:
            for k in list(sys.modules.keys()):
                if 'nexus' in k:
                    del sys.modules[k]
            mod_2 = importlib.import_module("nexus.services.local_heal.world_c_receipt")
            adapter_2.execute_subject({
                "function": mod_2.build_world_c_canonical_patch_projection,
                "source": src_2,
                "workspace": ws_2,
                "relative_path": "mod.py",
                "trusted_root": str(t_dir_2),
            })
        finally:
            if str(tree_a2) in sys.path:
                sys.path.remove(str(tree_a2))
        res_2 = kernel_2.evaluate_trace(adapter_2.trace)
        controls.append({
            "control_id": "benign-rv1-symlink-safe",
            "verdict": res_2.verdict.value,
            "status": "PASS_THROUGH" if res_2.verdict.value == "PASS" else "FP",
        })

        # Benign 3: Actual SpeculativeSandbox fork on regular isolated project dir
        commit_a3 = "c35be47cef9730a8ba89702560667e4c9a28c886"
        tree_a3 = self.materializer.materialize_tree(self.nexus_repo, commit_a3, "nexus/")
        kernel_3 = GenericRuntimeVerifierKernel()
        adapter_3 = ActualSandboxAdapter(kernel_3)
        t_dir_3 = Path(tempfile.mkdtemp())
        proj_3 = t_dir_3 / "my_project"
        proj_3.mkdir()
        (proj_3 / "app.py").write_text("print(1)\n")

        sys.path.insert(0, str(tree_a3))
        try:
            for k in list(sys.modules.keys()):
                if 'nexus' in k:
                    del sys.modules[k]
            mod_3 = importlib.import_module("nexus.health.sandbox")
            adapter_3.execute_subject({
                "sandbox_class": mod_3.SpeculativeSandbox,
                "source_root": proj_3,
                "authoritative_root": str(proj_3),
                "is_mutating": True,
            })
        finally:
            if str(tree_a3) in sys.path:
                sys.path.remove(str(tree_a3))
        res_3 = kernel_3.evaluate_trace(adapter_3.trace)
        controls.append({
            "control_id": "benign-rv2-temp-isolated",
            "verdict": res_3.verdict.value,
            "status": "PASS_THROUGH" if res_3.verdict.value == "PASS" else "FP",
        })

        # Benign 4: Actual RepairExecutor with clean sandbox execution (no fork leak)
        commit_a4 = "346f58196a4b0a1282e63d7df1eed3535578fca4"
        tree_a4 = self.materializer.materialize_tree(self.nexus_repo, commit_a4, "nexus/")
        kernel_4 = GenericRuntimeVerifierKernel()
        adapter_4 = ActualExecutorCleanupAdapter(kernel_4)
        t_dir_4 = Path(tempfile.mkdtemp())
        auth_root_4 = t_dir_4 / "repo"
        auth_root_4.mkdir()
        partial_root_4 = t_dir_4 / "nexus_sandbox_executor_benign_4"

        sys.path.insert(0, str(tree_a4))
        try:
            for k in list(sys.modules.keys()):
                if 'nexus' in k:
                    del sys.modules[k]
            mod_exec_4 = importlib.import_module("nexus.health.executor")
            executor_4 = mod_exec_4.RepairExecutor(repo_root=auth_root_4, task_runner=lambda _m: 0)
            adapter_4.execute_subject({
                "executor": executor_4,
                "authoritative_root": str(auth_root_4),
                "partial_root": partial_root_4,
            })
        finally:
            if str(tree_a4) in sys.path:
                sys.path.remove(str(tree_a4))

        res_4 = kernel_4.evaluate_trace(adapter_4.trace)
        controls.append({
            "control_id": "benign-rv2-readonly-root",
            "verdict": res_4.verdict.value,
            "status": "PASS_THROUGH" if res_4.verdict.value == "PASS" else "FP",
        })

        # Benign 5: Actual DurableOperationManager precondition pass
        kernel_5 = GenericRuntimeVerifierKernel()
        adapter_5 = ActualDurableOperationsAdapter(kernel_5)
        adapter_5.execute_subject({
            "raw_events": [{"type": "VALIDATION_PASS"}, {"type": "PROTECTED_EFFECT"}],
            "operation_id": "op-benign-5",
        })
        res_5 = kernel_5.evaluate_trace(adapter_5.trace)
        controls.append({
            "control_id": "benign-rv3-precondition-pass",
            "verdict": res_5.verdict.value,
            "status": "PASS_THROUGH" if res_5.verdict.value == "PASS" else "FP",
        })

        # Benign 6: Actual LocalAgentRuntimePool precondition fail and clean abort
        kernel_6 = GenericRuntimeVerifierKernel()
        adapter_6 = ActualRuntimePoolAdapter(kernel_6)
        adapter_6.execute_subject({
            "raw_events": [{"type": "VALIDATION_FAIL"}],
            "operation_id": "op-benign-6",
        })
        res_6 = kernel_6.evaluate_trace(adapter_6.trace)
        controls.append({
            "control_id": "benign-rv3-precondition-fail-clean",
            "verdict": res_6.verdict.value,
            "status": "PASS_THROUGH" if res_6.verdict.value == "PASS" else "FP",
        })

        return controls
