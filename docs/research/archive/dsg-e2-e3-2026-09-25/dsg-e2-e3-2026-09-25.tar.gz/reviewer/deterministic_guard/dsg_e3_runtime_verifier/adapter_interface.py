"""
Adapter Interface and Base Classes (DSG-E3)

Principles:
- Adapters intercept or wrap subject methods to emit RuntimeEvent traces.
- Adapters MUST NOT exceed 60 LOC.
- Adapters MUST NOT contain security verdicts or case assertions.
"""
from __future__ import annotations

import abc
from typing import Any, Dict, List

from reviewer.deterministic_guard.dsg_e3_runtime_verifier.kernel import (
    GenericRuntimeVerifierKernel,
    RuntimeEvent,
    VerificationResult,
)


class BaseSubjectAdapter(abc.ABC):
    """Abstract base class for subject instrumentation adapters."""

    def __init__(self, kernel: GenericRuntimeVerifierKernel):
        self.kernel = kernel
        self.trace: List[RuntimeEvent] = []

    def emit(self, event: RuntimeEvent) -> None:
        self.trace.append(event)

    def run_verification(self) -> VerificationResult:
        return self.kernel.evaluate_trace(self.trace)

    @abc.abstractmethod
    def execute_subject(self, input_payload: Dict[str, Any]) -> Any:
        """Run subject code under observation, emitting normalized events."""
        pass
