"""
Development Adapters for Anchor Cases #1, #2, #5 (DSG-E3)

Demonstrates thin instrumentation mapping subject actions to the generic kernel.
Strictly under 60 LOC per adapter.
"""
from __future__ import annotations

import os
import tempfile
from pathlib import Path
from typing import Any, Dict

from reviewer.deterministic_guard.dsg_e3_runtime_verifier.adapter_interface import BaseSubjectAdapter
from reviewer.deterministic_guard.dsg_e3_runtime_verifier.kernel import EventType, RuntimeEvent


class DevCase1StoreAdapter(BaseSubjectAdapter):
    """Adapter for Case #1 ExecutionStateStore path containment."""

    def execute_subject(self, input_payload: Dict[str, Any]) -> Any:
        state_dir = input_payload["state_dir"]
        task_id = input_payload["task_id"]
        store_cls = input_payload["store_class"]

        store = store_cls(state_dir=Path(state_dir), validate_writes=False)
        try:
            p = store.state_path(task_id)
            self.emit(RuntimeEvent(
                event_type=EventType.FS_EFFECT,
                target_path=str(p),
                trusted_root=str(state_dir),
            ))
            return p
        except ValueError as e:
            # Traversal rejected by post-fix validator before effect
            return None


class DevCase2WikiGateAdapter(BaseSubjectAdapter):
    """Adapter for Case #2 WikiCI subprocess isolation."""

    def execute_subject(self, input_payload: Dict[str, Any]) -> Any:
        runner_fn = input_payload["runner_function"]
        repo_root = Path(input_payload["repo_root"])

        def intercepted_run(argv, cwd=None, **kwargs):
            actual_cwd = cwd or repo_root
            is_ephemeral = "tmp" in str(actual_cwd).lower() or "temp" in str(actual_cwd).lower()
            self.emit(RuntimeEvent(
                event_type=EventType.PROC_EXEC,
                exec_cwd=str(actual_cwd),
                authoritative_root=str(repo_root),
                is_mutating=True,
                is_ephemeral=is_ephemeral,
            ))
            return 0

        return runner_fn(repo_root, intercepted_run)


class DevCase5CutoverAdapter(BaseSubjectAdapter):
    """Adapter for Case #5 DevSpace cutover validation ordering."""

    def execute_subject(self, input_payload: Dict[str, Any]) -> Any:
        cutover_fn = input_payload["cutover_function"]
        op_id = input_payload.get("operation_id", "cutover-1")

        def hook_validate(is_valid: bool):
            ev = EventType.VALIDATION_PASS if is_valid else EventType.VALIDATION_FAIL
            self.emit(RuntimeEvent(event_type=ev, operation_id=op_id))

        def hook_effect():
            self.emit(RuntimeEvent(event_type=EventType.PROTECTED_EFFECT, operation_id=op_id))

        return cutover_fn(hook_validate, hook_effect, input_payload.get("args", {}))
