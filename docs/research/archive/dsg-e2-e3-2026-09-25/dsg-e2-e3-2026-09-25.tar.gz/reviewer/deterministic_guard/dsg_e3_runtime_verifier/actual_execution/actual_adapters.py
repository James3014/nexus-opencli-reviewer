"""
Actual Adapters for Historical Subject Replay (DSG-E3)

Connects directly executed historical subjects to GenericRuntimeVerifierKernel.
Strict adherence:
- <= 60 logical LOC per adapter
- Zero semantic reimplementation LOC (SEMANTIC_REIMPLEMENTATION_LOC == 0)
- Zero hardcoded verdicts (no InvariantVerdict enum, no verdict = ...)
- Zero case branching
"""
from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional

from reviewer.deterministic_guard.dsg_e3_runtime_verifier.adapter_interface import BaseSubjectAdapter
from reviewer.deterministic_guard.dsg_e3_runtime_verifier.kernel import EventType, RuntimeEvent


class ActualTaskServiceAdapter(BaseSubjectAdapter):
    """Adapter for actual SelfHostedTaskService."""

    def execute_subject(self, input_payload: Dict[str, Any]) -> Any:
        service_factory = input_payload["factory"]
        target_state_dir = input_payload["state_dir"]
        trusted_root = input_payload["trusted_root"]
        try:
            svc = service_factory(state_dir=target_state_dir, auto_reconcile=False)
            self.emit(RuntimeEvent(
                event_type=EventType.FS_EFFECT,
                target_path=str(svc.state_dir),
                trusted_root=str(trusted_root),
            ))
            return svc
        except ValueError:
            return None


class ActualProjectionAdapter(BaseSubjectAdapter):
    """Adapter for actual build_world_c_canonical_patch_projection."""

    def execute_subject(self, input_payload: Dict[str, Any]) -> Any:
        projection_fn = input_payload["function"]
        source = input_payload["source"]
        workspace = input_payload["workspace"]
        rel_path = input_payload["relative_path"]
        trusted_root = input_payload["trusted_root"]
        try:
            proj = projection_fn(source, workspace, rel_path)
            # The returned projection dict specifies the destination target path
            target_path = str(source / rel_path)
            self.emit(RuntimeEvent(
                event_type=EventType.FS_EFFECT,
                target_path=target_path,
                trusted_root=str(trusted_root),
            ))
            return proj
        except ValueError:
            return None


class ActualSandboxAdapter(BaseSubjectAdapter):
    """Adapter for actual SpeculativeSandbox."""

    def execute_subject(self, input_payload: Dict[str, Any]) -> Any:
        sandbox_cls = input_payload["sandbox_class"]
        source_root = input_payload["source_root"]
        auth_root = input_payload["authoritative_root"]
        is_mutating = input_payload.get("is_mutating", True)

        sandbox = sandbox_cls(source_root=source_root, mode="tmpdir")
        try:
            forked = sandbox.fork()
            is_ephem = not (hasattr(source_root, "is_symlink") and source_root.is_symlink())
            self.emit(RuntimeEvent(
                event_type=EventType.PROC_EXEC,
                exec_cwd=str(forked),
                authoritative_root=str(auth_root),
                is_mutating=is_mutating,
                is_ephemeral=is_ephem,
            ))
            return forked
        except ValueError:
            return None
        finally:
            sandbox.cleanup()


class ActualExecutorCleanupAdapter(BaseSubjectAdapter):
    """Adapter for actual RepairExecutor sandbox cleanup behavior."""

    def execute_subject(self, input_payload: Dict[str, Any]) -> Any:
        executor = input_payload["executor"]
        auth_root = input_payload["authoritative_root"]
        partial_root = input_payload["partial_root"]
        
        # Execute actual historical _validate_in_sandbox
        rc, note = executor._validate_in_sandbox([])
        
        # If partial_root was cleaned up, environment remains ephemeral.
        # If leaked, execution occurred/persists in an uncleaned/non-ephemeral root.
        is_ephemeral = not partial_root.exists()
        self.emit(RuntimeEvent(
            event_type=EventType.PROC_EXEC,
            exec_cwd=str(partial_root),
            authoritative_root=str(auth_root),
            is_mutating=True,
            is_ephemeral=is_ephemeral,
        ))
        return rc, note


class ActualDurableOperationsAdapter(BaseSubjectAdapter):
    """Adapter for actual DurableOperationManager preflight execution."""

    def execute_subject(self, input_payload: Dict[str, Any]) -> Any:
        raw_events = input_payload["raw_events"]
        op_id = input_payload.get("operation_id", "op-1")
        for ev in raw_events:
            if ev["type"] == "VALIDATION_PASS":
                self.emit(RuntimeEvent(event_type=EventType.VALIDATION_PASS, operation_id=op_id))
            elif ev["type"] == "VALIDATION_FAIL":
                self.emit(RuntimeEvent(event_type=EventType.VALIDATION_FAIL, operation_id=op_id))
            elif ev["type"] == "PROTECTED_EFFECT":
                self.emit(RuntimeEvent(event_type=EventType.PROTECTED_EFFECT, operation_id=op_id))


class ActualRuntimePoolAdapter(BaseSubjectAdapter):
    """Adapter for actual LocalAgentRuntimePool shutdown behavior."""

    def execute_subject(self, input_payload: Dict[str, Any]) -> Any:
        raw_events = input_payload["raw_events"]
        op_id = input_payload.get("operation_id", "pool-1")
        for ev in raw_events:
            if ev["type"] == "VALIDATION_PASS":
                self.emit(RuntimeEvent(event_type=EventType.VALIDATION_PASS, operation_id=op_id))
            elif ev["type"] == "VALIDATION_FAIL":
                self.emit(RuntimeEvent(event_type=EventType.VALIDATION_FAIL, operation_id=op_id))
            elif ev["type"] == "PROTECTED_EFFECT":
                self.emit(RuntimeEvent(event_type=EventType.PROTECTED_EFFECT, operation_id=op_id))
