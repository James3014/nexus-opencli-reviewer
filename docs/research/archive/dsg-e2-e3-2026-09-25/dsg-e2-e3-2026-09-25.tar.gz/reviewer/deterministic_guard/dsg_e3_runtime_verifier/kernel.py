"""
Generic Runtime Verifier Kernel & Event Schema (DSG-E3)

Core Principles:
1. Pure invariant evaluator with ZERO knowledge of repos, commits, or test case IDs.
2. Evaluates normalized runtime event traces against RV1, RV2, RV3 formal contracts.
3. Completely decoupled from subject adapters.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


class EventType(str, Enum):
    FS_RESOLVE = "FS_RESOLVE"
    FS_EFFECT = "FS_EFFECT"
    PROC_EXEC = "PROC_EXEC"
    VALIDATION_START = "VALIDATION_START"
    VALIDATION_PASS = "VALIDATION_PASS"
    VALIDATION_FAIL = "VALIDATION_FAIL"
    PROTECTED_EFFECT = "PROTECTED_EFFECT"


@dataclass(frozen=True)
class RuntimeEvent:
    event_type: EventType
    target_path: Optional[str] = None
    trusted_root: Optional[str] = None
    exec_cwd: Optional[str] = None
    authoritative_root: Optional[str] = None
    is_mutating: bool = False
    is_ephemeral: bool = False
    operation_id: Optional[str] = None
    payload: Dict[str, Any] = field(default_factory=dict)


class InvariantVerdict(str, Enum):
    PASS = "PASS"
    VIOLATION = "VIOLATION"


@dataclass
class VerificationResult:
    verdict: InvariantVerdict
    violations: List[str] = field(default_factory=list)
    event_count: int = 0


class GenericRuntimeVerifierKernel:
    """
    Generic runtime verifier implementing RV1, RV2, RV3 contracts.
    Must NOT contain any domain-specific strings, case IDs, or repository logic.
    """

    def evaluate_trace(self, trace: List[RuntimeEvent]) -> VerificationResult:
        violations: List[str] = []

        # State tracking for RV3 validation-precedes-effect ordering
        validated_operations = set()
        failed_operations = set()

        for idx, event in enumerate(trace):
            # -------------------------------------------------------------
            # RV1: TRUSTED_ROOT_CONTAINMENT
            # Target path of effect must resolve strictly within trusted_root
            # -------------------------------------------------------------
            if event.event_type in (EventType.FS_RESOLVE, EventType.FS_EFFECT):
                if event.target_path and event.trusted_root:
                    try:
                        resolved_target = Path(os.path.realpath(event.target_path))
                        resolved_root = Path(os.path.realpath(event.trusted_root))
                        if not resolved_target.is_relative_to(resolved_root):
                            violations.append(
                                f"RV1_VIOLATION at event {idx}: target {event.target_path!r} "
                                f"resolves to {resolved_target} outside trusted root {resolved_root}"
                            )
                    except Exception as err:
                        violations.append(f"RV1_ERROR at event {idx}: {err}")

            # -------------------------------------------------------------
            # RV2: ISOLATED_EXECUTION_ROOT
            # Mutating process execution must NOT use authoritative root as cwd
            # -------------------------------------------------------------
            elif event.event_type == EventType.PROC_EXEC:
                if event.is_mutating and event.exec_cwd and event.authoritative_root:
                    try:
                        resolved_cwd = Path(os.path.realpath(event.exec_cwd))
                        resolved_auth = Path(os.path.realpath(event.authoritative_root))
                        if resolved_cwd == resolved_auth:
                            violations.append(
                                f"RV2_VIOLATION at event {idx}: mutating execution directly in "
                                f"authoritative root {resolved_auth}"
                            )
                        elif not event.is_ephemeral:
                            violations.append(
                                f"RV2_VIOLATION at event {idx}: execution cwd {resolved_cwd} is not ephemeral"
                            )
                    except Exception as err:
                        violations.append(f"RV2_ERROR at event {idx}: {err}")

            # -------------------------------------------------------------
            # RV3: VALIDATION_PRECEDES_PROTECTED_EFFECT
            # Protected effect requires preceding VALIDATION_PASS and no FAIL
            # -------------------------------------------------------------
            elif event.event_type == EventType.VALIDATION_PASS:
                op_id = event.operation_id or "default"
                validated_operations.add(op_id)

            elif event.event_type == EventType.VALIDATION_FAIL:
                op_id = event.operation_id or "default"
                failed_operations.add(op_id)

            elif event.event_type == EventType.PROTECTED_EFFECT:
                op_id = event.operation_id or "default"
                if op_id in failed_operations:
                    violations.append(
                        f"RV3_VIOLATION at event {idx}: protected effect executed after validation failure for {op_id}"
                    )
                elif op_id not in validated_operations:
                    violations.append(
                        f"RV3_VIOLATION at event {idx}: protected effect executed without preceding validation for {op_id}"
                    )

        verdict = InvariantVerdict.VIOLATION if violations else InvariantVerdict.PASS
        return VerificationResult(
            verdict=verdict,
            violations=violations,
            event_count=len(trace),
        )
