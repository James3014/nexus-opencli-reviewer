"""
Physical Subject Adapters (DSG-E3 Recovery)

Connects materialized historical code to the GenericRuntimeVerifierKernel.
Strictly under 60 LOC per adapter.
ZERO security verdicts, case branching, or expected outcomes.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Callable, Dict, List

from reviewer.deterministic_guard.dsg_e3_runtime_verifier.adapter_interface import BaseSubjectAdapter
from reviewer.deterministic_guard.dsg_e3_runtime_verifier.kernel import EventType, RuntimeEvent


class PhysicalTaskServiceAdapter(BaseSubjectAdapter):
    """Adapter for TaskService self_hosted_task_service.py (6f0a50c)."""

    def execute_subject(self, input_payload: Dict[str, Any]) -> Any:
        func = input_payload["callable"]
        base_dir = input_payload["base_dir"]
        try:
            target = func(base_dir)
            self.emit(RuntimeEvent(
                event_type=EventType.FS_EFFECT,
                target_path=str(target),
                trusted_root=str(base_dir),
            ))
            return target
        except ValueError:
            return None


class PhysicalProjectionAdapter(BaseSubjectAdapter):
    """Adapter for world_c_receipt.py projection root (c8e7c50)."""

    def execute_subject(self, input_payload: Dict[str, Any]) -> Any:
        func = input_payload["callable"]
        target = input_payload["target_path"]
        trusted_root = input_payload["trusted_root"]
        try:
            res = func(trusted_root, target)
            self.emit(RuntimeEvent(
                event_type=EventType.FS_EFFECT,
                target_path=str(res),
                trusted_root=str(trusted_root),
            ))
            return res
        except ValueError:
            return None


class PhysicalSandboxAdapter(BaseSubjectAdapter):
    """Adapter for sandbox.py isolated execution (c35be47)."""

    def execute_subject(self, input_payload: Dict[str, Any]) -> Any:
        func = input_payload["callable"]
        repo_root = input_payload["repo_root"]

        def intercept_proc(cwd: str, mutating: bool, ephemeral: bool):
            self.emit(RuntimeEvent(
                event_type=EventType.PROC_EXEC,
                exec_cwd=str(cwd),
                authoritative_root=str(repo_root),
                is_mutating=mutating,
                is_ephemeral=ephemeral,
            ))

        return func(repo_root, intercept_proc)


class PhysicalExecutorCleanupAdapter(BaseSubjectAdapter):
    """Adapter for executor.py sandbox cleanup after validation (346f581)."""

    def execute_subject(self, input_payload: Dict[str, Any]) -> Any:
        func = input_payload["callable"]
        auth_root = input_payload["auth_root"]

        def intercept_proc(cwd: str, is_mutating: bool, is_ephemeral: bool):
            self.emit(RuntimeEvent(
                event_type=EventType.PROC_EXEC,
                exec_cwd=str(cwd),
                authoritative_root=str(auth_root),
                is_mutating=is_mutating,
                is_ephemeral=is_ephemeral,
            ))

        return func(auth_root, intercept_proc)


class PhysicalShutdownFencingAdapter(BaseSubjectAdapter):
    """Adapter for local-agent-runtime-pool.ts shutdown fencing (22a5ebf)."""

    def execute_subject(self, input_payload: Dict[str, Any]) -> Any:
        func = input_payload["callable"]
        op_id = input_payload.get("op_id", "shutdown-op-1")

        def hook_validate(can_release: bool):
            ev = EventType.VALIDATION_PASS if can_release else EventType.VALIDATION_FAIL
            self.emit(RuntimeEvent(event_type=ev, operation_id=op_id))

        def hook_effect():
            self.emit(RuntimeEvent(event_type=EventType.PROTECTED_EFFECT, operation_id=op_id))

        return func(hook_validate, hook_effect, input_payload.get("params", {}))


class PhysicalGatewayFencingAdapter(BaseSubjectAdapter):
    """Adapter for durable-operations.ts preflight fencing (56335f7)."""

    def execute_subject(self, input_payload: Dict[str, Any]) -> Any:
        func = input_payload["callable"]
        op_id = input_payload.get("op_id", "gateway-op-1")

        def hook_validate(can_proceed: bool):
            ev = EventType.VALIDATION_PASS if can_proceed else EventType.VALIDATION_FAIL
            self.emit(RuntimeEvent(event_type=ev, operation_id=op_id))

        def hook_effect():
            self.emit(RuntimeEvent(event_type=EventType.PROTECTED_EFFECT, operation_id=op_id))

        return func(hook_validate, hook_effect, input_payload.get("params", {}))
