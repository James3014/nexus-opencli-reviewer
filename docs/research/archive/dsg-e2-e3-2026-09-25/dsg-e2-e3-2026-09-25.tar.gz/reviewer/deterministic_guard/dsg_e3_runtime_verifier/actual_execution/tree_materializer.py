"""
Actual Execution Tree Materializer (DSG-E3 Actual Historical Execution Proof)

Extracts complete Git archive trees for historical commits into isolated temporary directories.
Ensures zero mutation of source repositories.
"""
from __future__ import annotations

import os
from pathlib import Path
import shutil
import subprocess
import tempfile
from typing import Dict, Optional


class TreeMaterializer:
    """Materializes full historical trees from source git repositories via git archive."""

    def __init__(self, base_tmp_dir: Optional[Path] = None):
        self.base_tmp_dir = base_tmp_dir or Path(tempfile.gettempdir()) / "dsg_e3_actual_trees"
        self.base_tmp_dir.mkdir(parents=True, exist_ok=True)
        self.allocated_trees: Dict[str, Path] = {}

    def materialize_tree(self, repo_dir: str, commit_sha: str, subpath: Optional[str] = None) -> Path:
        """
        Materialize git archive of commit_sha from repo_dir.
        Returns the Path to the materialized directory.
        """
        key = f"{Path(repo_dir).name}_{commit_sha[:10]}"
        target_dir = self.base_tmp_dir / key
        if target_dir.exists() and (target_dir / ".materialized_success").exists():
            return target_dir

        if target_dir.exists():
            shutil.rmtree(target_dir, ignore_errors=True)
        target_dir.mkdir(parents=True, exist_ok=True)

        cmd = ["git", "archive", commit_sha]
        if subpath:
            cmd.append(subpath)

        archive_proc = subprocess.run(
            cmd,
            cwd=repo_dir,
            capture_output=True,
            check=False,
        )
        if archive_proc.returncode != 0:
            raise RuntimeError(
                f"git archive failed for {repo_dir} @ {commit_sha}: {archive_proc.stderr.decode(errors='replace')}"
            )

        tar_proc = subprocess.run(
            ["tar", "-x", "-C", str(target_dir)],
            input=archive_proc.stdout,
            capture_output=True,
            check=False,
        )
        if tar_proc.returncode != 0:
            raise RuntimeError(
                f"tar extract failed for {target_dir}: {tar_proc.stderr.decode(errors='replace')}"
            )

        # If repo is devspace, symlink the pre-existing node_modules into temp tree
        devspace_nm = Path(repo_dir) / "node_modules"
        if devspace_nm.exists() and not (target_dir / "node_modules").exists():
            try:
                os.symlink(str(devspace_nm), str(target_dir / "node_modules"))
            except OSError:
                pass

        (target_dir / ".materialized_success").write_text(f"commit={commit_sha}\nrepo={repo_dir}\n")
        self.allocated_trees[key] = target_dir
        return target_dir

    def cleanup_all(self):
        """Remove all temporary materialized trees."""
        if self.base_tmp_dir.exists():
            shutil.rmtree(self.base_tmp_dir, ignore_errors=True)
