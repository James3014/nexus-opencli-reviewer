"""
Holdout Adapters for Unseen Cases (DSG-E3)

Principles:
- Thin wrappers mapping subject entry parameters into RuntimeEvent objects.
- Each adapter strictly under 60 LOC.
- Zero case branching or expected verdict logic.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Dict

from reviewer.deterministic_guard.dsg_e3_runtime_verifier.adapter_interface import BaseSubjectAdapter
from reviewer.deterministic_guard.dsg_e3_runtime_verifier.kernel import EventType, RuntimeEvent


class HoldoutRV1TaskServiceAdapter(BaseSubjectAdapter):
    """Adapter for TaskService runner temp root validation (6f0a50c)."""

    def execute_subject(self, input_payload: Dict[str, Any]) -> Any:
        base_dir = input_payload["base_dir"]
        runner_fn = input_payload["runner_function"]

        try:
            resolved_target = runner_fn(base_dir)
            self.emit(RuntimeEvent(
                event_type=EventType.FS_EFFECT,
                target_path=str(resolved_target),
                trusted_root=str(base_dir),
            ))
            return resolved_target
        except ValueError:
            # Traversal or symlink rejected before effect
            return None


class HoldoutRV1ProjectionAdapter(BaseSubjectAdapter):
    """Adapter for World C projection root validation (c8e7c50)."""

    def execute_subject(self, input_payload: Dict[str, Any]) -> Any:
        target_path = input_payload["target_path"]
        trusted_root = input_payload["trusted_root"]
        resolver_fn = input_payload["resolver_function"]

        try:
            p = resolver_fn(trusted_root, target_path)
            self.emit(RuntimeEvent(
                event_type=EventType.FS_EFFECT,
                target_path=str(p),
                trusted_root=str(trusted_root),
            ))
            return p
        except ValueError:
            return None


class HoldoutRV2SandboxAdapter(BaseSubjectAdapter):
    """Adapter for health sandbox execution isolation (c35be47)."""

    def execute_subject(self, input_payload: Dict[str, Any]) -> Any:
        sandbox_fn = input_payload["sandbox_function"]
        repo_root = input_payload["repo_root"]

        def hook_proc(cwd: str, mutating: bool, ephemeral: bool):
            self.emit(RuntimeEvent(
                event_type=EventType.PROC_EXEC,
                exec_cwd=str(cwd),
                authoritative_root=str(repo_root),
                is_mutating=mutating,
                is_ephemeral=ephemeral,
            ))

        return sandbox_fn(repo_root, hook_proc)


class HoldoutRV3ShutdownAdapter(BaseSubjectAdapter):
    """Adapter for local agent runtime pool shutdown fencing (22a5ebf)."""

    def execute_subject(self, input_payload: Dict[str, Any]) -> Any:
        release_fn = input_payload["release_function"]
        op_id = input_payload.get("op_id", "session-release-1")

        def hook_validate(can_release: bool):
            ev = EventType.VALIDATION_PASS if can_release else EventType.VALIDATION_FAIL
            self.emit(RuntimeEvent(event_type=ev, operation_id=op_id))

        def hook_effect():
            self.emit(RuntimeEvent(event_type=EventType.PROTECTED_EFFECT, operation_id=op_id))

        return release_fn(hook_validate, hook_effect, input_payload.get("params", {}))
