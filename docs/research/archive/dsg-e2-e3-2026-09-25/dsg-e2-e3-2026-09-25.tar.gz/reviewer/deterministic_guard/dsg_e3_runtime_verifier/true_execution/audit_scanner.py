"""
Static Audit for Semantic Reimplementation & Harness Artifacts (DSG-E3)

Audits true_execution/ against:
- copied historical validation expression
- copied before/fix semantics
- if commit == / if case_id ==
- expected-verdict branch
- hand-written callable before/after
"""
from __future__ import annotations

import ast
from pathlib import Path
from typing import Any, Dict, List


FORBIDDEN_PATTERNS = [
    "if commit ==",
    "if case_id ==",
    "is_before",
    "callable_1b",
    "callable_1a",
    "callable_2b",
    "callable_2a",
    "callable_3b",
    "callable_3a",
    "callable_4b",
    "callable_4a",
    "callable_5b",
    "callable_5a",
    "callable_6b",
    "callable_6a",
    "source_root.is_symlink()",
]


def audit_file(path: Path) -> Dict[str, Any]:
    text = path.read_text(encoding="utf-8")
    violations = []
    for pattern in FORBIDDEN_PATTERNS:
        if pattern in text:
            violations.append(f"Forbidden pattern detected: {pattern!r}")
    
    # Check for hardcoded verdicts in adapter methods
    if "InvariantVerdict.PASS" in text or "InvariantVerdict.VIOLATION" in text:
        violations.append("Reference to InvariantVerdict in adapter/runner code")

    return {
        "file": str(path),
        "violations": violations,
        "semantic_reimplementation_loc": 0 if not violations else len(violations),
        "status": "PASS" if not violations else "FAIL",
    }


def run_audit(target_dir: Path) -> Dict[str, Any]:
    results = []
    total_reimpl_loc = 0
    for py_file in target_dir.glob("*.py"):
        if py_file.name == "audit_scanner.py":
            continue
        res = audit_file(py_file)
        results.append(res)
        total_reimpl_loc += res["semantic_reimplementation_loc"]

    return {
        "version": "v2",
        "audit_target": str(target_dir),
        "total_semantic_reimplementation_loc": total_reimpl_loc,
        "files_audited": results,
        "status": "PASS" if total_reimpl_loc == 0 else "FAIL",
    }


if __name__ == "__main__":
    target = Path("reviewer/deterministic_guard/dsg_e3_runtime_verifier/true_execution")
    out = run_audit(target)
    print(out)
